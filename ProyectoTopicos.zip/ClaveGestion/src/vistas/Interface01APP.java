package vistas;

import controlador.ConexionLogin;
import controlador.UsuarioLogin;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Interface01APP extends JFrame {
  ConexionLogin cConexionLogin = new ConexionLogin();
  
  UsuarioLogin cUsuarioLogin = new UsuarioLogin();
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3_imagenFondo;
  
  private JPanel jPanel1;
  
  private JSeparator jSeparator1;
  
  private JSeparator jSeparator2;
  
  public Interface01APP() {
    initComponents();
    setLocationRelativeTo((Component)null);
    setResizable(false);
    setTitle("ClaveGestion | Iniciando el programa...");
  }
  
  private void initComponents() {
    this.jPanel1 = new JPanel();
    this.jLabel3_imagenFondo = new JLabel();
    this.jLabel1 = new JLabel();
    this.jLabel2 = new JLabel();
    this.jSeparator1 = new JSeparator();
    this.jSeparator2 = new JSeparator();
    setDefaultCloseOperation(3);
    setMinimumSize(new Dimension(800, 600));
    setPreferredSize(new Dimension(800, 600));
    addWindowListener(new WindowAdapter() {
          public void windowOpened(WindowEvent evt) {
            Interface01APP.this.formWindowOpened(evt);
          }
        });
    this.jPanel1.setBackground(new Color(220, 218, 243));
    this.jLabel3_imagenFondo.setIcon(new ImageIcon(getClass().getResource("/images/20150924-00-claveGestion-caratulaPresent03.png")));
    this.jLabel1.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel1.setText("Por favor espere ...");
    this.jLabel2.setFont(new Font("Ubuntu", 1, 16));
    this.jLabel2.setForeground(new Color(109, 101, 101));
    this.jLabel2.setText("Juan Aldana");
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jSeparator2).addComponent(this.jSeparator1, GroupLayout.Alignment.TRAILING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addGap(0, 595, 32767).addComponent(this.jLabel2, -2, 193, -2))).addContainerGap()).addComponent(this.jLabel3_imagenFondo, -1, -1, 32767).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.jLabel1, -2, 333, -2).addGap(161, 161, 161)));
    jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel3_imagenFondo).addGap(35, 35, 35).addComponent(this.jLabel1, -2, 80, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 175, 32767).addComponent(this.jSeparator2, -2, -1, -2).addGap(18, 18, 18).addComponent(this.jLabel2, -2, 26, -2).addGap(18, 18, 18).addComponent(this.jSeparator1, -2, -1, -2).addGap(35, 35, 35)));
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767));
    layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767));
    pack();
  }
  
  private void formWindowOpened(WindowEvent evt) {
    try {
      this.cConexionLogin.conexionLoginFirst();
      this.cUsuarioLogin.controlUsuario();
      dispose();
    } catch (Exception ex) {
      Logger.getLogger(Interface01APP.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Interface01APP.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(Interface01APP.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(Interface01APP.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(Interface01APP.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Interface01APP()).setVisible(true);
          }
        });
  }
}


