package vistas;

import controlador.JMenuBar;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Interface1000AboutMe extends JFrame {
  private JButton jButton_Close;
  
  private JLabel jLabel1;
  
  private JPanel jPanel1;
  
  private JScrollPane jScrollPane1;
  
  private JSeparator jSeparator2;
  
  private JTextArea jTextArea1;
  
  public Interface1000AboutMe() {
    initComponents();
    setLocationRelativeTo((Component)null);
    setResizable(false);
    setTitle("Acerca de ClaveGestion | Juan Aldana");
    setDefaultCloseOperation(0);
  }
  
  private void initComponents() {
    this.jPanel1 = new JPanel();
    this.jLabel1 = new JLabel();
    this.jButton_Close = new JButton();
    this.jSeparator2 = new JSeparator();
    this.jScrollPane1 = new JScrollPane();
    this.jTextArea1 = new JTextArea();
    setDefaultCloseOperation(3);
    setMaximumSize(null);
    setMinimumSize(new Dimension(401, 225));
    this.jPanel1.setBackground(new Color(220, 218, 243));
    this.jPanel1.setMaximumSize((Dimension)null);
    this.jPanel1.setMinimumSize(new Dimension(401, 225));
    this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/images/20150924-00-claveGestion-caratulaPresent04.png")));
    this.jLabel1.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Interface1000AboutMe.this.jLabel1MouseClicked(evt);
          }
        });
    this.jButton_Close.setFont(new Font("Ubuntu", 1, 15));
    this.jButton_Close.setText("Cerrar");
    this.jButton_Close.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface1000AboutMe.this.jButton_CloseActionPerformed(evt);
          }
        });
    this.jTextArea1.setEditable(false);
    this.jTextArea1.setColumns(20);
    this.jTextArea1.setFont(new Font("Ubuntu", 1, 15));
    this.jTextArea1.setForeground(new Color(80, 72, 193));
    this.jTextArea1.setRows(2);
    this.jTextArea1.setText("    Este software est� desarrollado por: Juan Aldana.\n                 Pincha aqui para mas informacion.");
    this.jTextArea1.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Interface1000AboutMe.this.jTextArea1MouseClicked(evt);
          }
        });
    this.jScrollPane1.setViewportView(this.jTextArea1);
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.jButton_Close, -2, 104, -2).addGap(146, 146, 146)).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jSeparator2).addContainerGap()).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jLabel1, -2, 400, -2).addComponent(this.jScrollPane1, -2, 401, -2)).addGap(0, 0, 32767)));
    jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -2, 46, -2).addGap(18, 18, 18).addComponent(this.jSeparator2, -2, 6, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jButton_Close).addContainerGap(-1, 32767)));
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767));
    layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767));
    pack();
  }
  
  private void jButton_CloseActionPerformed(ActionEvent evt) {
    dispose();
  }
  
  private void jTextArea1MouseClicked(MouseEvent evt) {
    try {
      JMenuBar.LinkURL("https://www.instagram.com/juanaldanav/");
      dispose();
    } catch (URISyntaxException ex) {
      Logger.getLogger(Interface1000AboutMe.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jLabel1MouseClicked(MouseEvent evt) {
    try {
      JMenuBar.LinkURL("https://github.com/juanaldanav");
      dispose();
    } catch (URISyntaxException ex) {
      Logger.getLogger(Interface1000AboutMe.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Interface1000AboutMe.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(Interface1000AboutMe.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(Interface1000AboutMe.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(Interface1000AboutMe.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Interface1000AboutMe()).setVisible(true);
          }
        });
  }
}


