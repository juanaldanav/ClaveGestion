package vistas;

import controlador.JMenuBar;
import controlador.Organizador;
import controlador.UsuarioLogin;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import modelos.Usuario;
import tb.controlador.Utilities;

public class Interface02Registro extends JFrame {
  UsuarioLogin cUsuarioLogin = new UsuarioLogin();
  
  Organizador organizador = new Organizador();
  
  Utilities utilities = new Utilities();
  
  private JButton jButton_CrearUsuario;
  
  private JButton jButton_Reset;
  
  private JLabel jLabel1;
  
  private JLabel jLabel3;
  
  private JLabel jLabel4;
  
  private JLabel jLabel5;
  
  public JMenu jMenu1;
  
  public JMenu jMenu3;
  
  private JMenuBar jMenuBar1;
  
  private JMenuItem jMenuItem_About;
  
  private JMenuItem jMenuItem_Ayuda;
  
  private JMenuItem jMenuItem_ModificarUser;
  
  private JMenuItem jMenuItem_Opinion;
  
  private JMenuItem jMenuItem_Salir;
  
  private JMenuItem jMenuItem_passGenerator;
  
  private JMenu jMenu_ModificarUsuario;
  
  private JPanel jPanel1;
  
  private JScrollPane jScrollPane1;
  
  private JPopupMenu.Separator jSeparator1;
  
  private JSeparator jSeparator2;
  
  private JPopupMenu.Separator jSeparator3;
  
  private JTextArea jTextArea1;
  
  private JTextField jTextField_NameUser;
  
  private JTextField jTextField_PassUser;
  
  private JTextField jTextField_RePassUser;
  
  public Interface02Registro() {
    initComponents();
    setLocationRelativeTo(null);
    setResizable(false);
    setTitle("ClaveGestión | Crear Usuario:");
    this.organizador.reset3(this.jTextField_NameUser, this.jTextField_PassUser, this.jTextField_RePassUser);
  }
  
  private void initComponents() {
    this.jPanel1 = new JPanel();
    this.jLabel1 = new JLabel();
    this.jScrollPane1 = new JScrollPane();
    this.jTextArea1 = new JTextArea();
    this.jSeparator2 = new JSeparator();
    this.jLabel3 = new JLabel();
    this.jLabel4 = new JLabel();
    this.jLabel5 = new JLabel();
    this.jTextField_NameUser = new JTextField();
    this.jTextField_RePassUser = new JTextField();
    this.jTextField_PassUser = new JTextField();
    this.jButton_CrearUsuario = new JButton();
    this.jButton_Reset = new JButton();
    this.jMenuBar1 = new JMenuBar();
    this.jMenu_ModificarUsuario = new JMenu();
    this.jMenuItem_ModificarUser = new JMenuItem();
    this.jSeparator1 = new JPopupMenu.Separator();
    this.jMenuItem_Salir = new JMenuItem();
    this.jMenu3 = new JMenu();
    this.jMenuItem_passGenerator = new JMenuItem();
    this.jMenu1 = new JMenu();
    this.jMenuItem_Ayuda = new JMenuItem();
    this.jMenuItem_Opinion = new JMenuItem();
    this.jSeparator3 = new JPopupMenu.Separator();
    this.jMenuItem_About = new JMenuItem();
    setDefaultCloseOperation(3);
    setMinimumSize(new Dimension(800, 600));
    setResizable(false);
    this.jPanel1.setBackground(new Color(170, 169, 193));
    this.jLabel1.setFont(new Font("Ubuntu", 1, 14));
    this.jLabel1.setText("Cofiguración inicial del programa: Crear un Usuario y Contraseña.");
    this.jTextArea1.setEditable(false);
    this.jTextArea1.setColumns(20);
    this.jTextArea1.setRows(5);
    this.jTextArea1.setText("\tEsto servirá para entrar en su Gestor de Contraseñas de manera privada,  \n\tal tiempo que protejerá sus datos de personas ajenas.\n\tDebe recordar esta contraseña inicial, si la olvida perderá el acceso al programa.\n\n\tMás adelante podrá cambiar la contraseña y el nombre de usuario, si así lo desea.");
    this.jScrollPane1.setViewportView(this.jTextArea1);
    this.jLabel3.setFont(new Font("Ubuntu", 1, 14));
    this.jLabel3.setText("Nombre de Usuario (máximo 30 caracteres):");
    this.jLabel4.setFont(new Font("Ubuntu", 1, 14));
    this.jLabel4.setText("Contraseña (máximo 20 caracteres):");
    this.jLabel5.setFont(new Font("Ubuntu", 1, 14));
    this.jLabel5.setText("Repita la Contraseña:");
    this.jTextField_NameUser.setText("jTextField1");
    this.jTextField_RePassUser.setText("jTextField1");
    this.jTextField_RePassUser.setMaximumSize(new Dimension(86, 27));
    this.jTextField_RePassUser.setMinimumSize(new Dimension(86, 27));
    this.jTextField_RePassUser.setName("");
    this.jTextField_PassUser.setText("jTextField1");
    this.jTextField_PassUser.setMaximumSize(new Dimension(86, 27));
    this.jTextField_PassUser.setMinimumSize(new Dimension(86, 27));
    this.jTextField_PassUser.setName("");
    this.jButton_CrearUsuario.setText("Crear Usuario");
    this.jButton_CrearUsuario.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jButton_CrearUsuarioActionPerformed(evt);
          }
        });
    this.jButton_Reset.setText("Reset");
    this.jButton_Reset.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jButton_ResetActionPerformed(evt);
          }
        });
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.jButton_CrearUsuario).addGap(85, 85, 85).addComponent(this.jButton_Reset).addGap(277, 277, 277)).addComponent(this.jScrollPane1).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jSeparator2).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.jLabel1, -1, 750, 32767).addComponent(this.jLabel3, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jTextField_NameUser, GroupLayout.Alignment.LEADING).addComponent(this.jLabel4, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jLabel5, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jTextField_RePassUser, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.jTextField_PassUser, GroupLayout.Alignment.LEADING, -1, -1, 32767)).addGap(0, 0, 32767))).addContainerGap()));
    jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel1, -2, 41, -2).addGap(18, 18, 18).addComponent(this.jScrollPane1, -2, 87, -2).addGap(18, 18, 18).addComponent(this.jSeparator2, -2, -1, -2).addGap(33, 33, 33).addComponent(this.jLabel3, -2, 30, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jTextField_NameUser, -2, -1, -2).addGap(18, 18, 18).addComponent(this.jLabel4, -2, 30, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jTextField_PassUser, -2, -1, -2).addGap(18, 18, 18).addComponent(this.jLabel5, -2, 30, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jTextField_RePassUser, -2, -1, -2).addGap(36, 36, 36).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton_CrearUsuario).addComponent(this.jButton_Reset)).addContainerGap(56, 32767)));
    this.jMenu_ModificarUsuario.setText("Archivo");
    this.jMenuItem_ModificarUser.setText("Modificar la Contraseña de Acceso al Programa");
    this.jMenuItem_ModificarUser.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jMenuItem_ModificarUserActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_ModificarUser);
    this.jMenu_ModificarUsuario.add(this.jSeparator1);
    this.jMenuItem_Salir.setText("Salir");
    this.jMenuItem_Salir.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jMenuItem_SalirActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_Salir);
    this.jMenu3.setText("Herramientas");
    this.jMenuItem_passGenerator.setText("Generador de Contrase�as");
    this.jMenuItem_passGenerator.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jMenuItem_passGeneratorActionPerformed(evt);
          }
        });
    this.jMenu3.add(this.jMenuItem_passGenerator);
    this.jMenu1.setText("Ayuda");
    this.jMenuItem_Ayuda.setText("Ayuda de ClaveGestión");
    this.jMenuItem_Ayuda.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jMenuItem_AyudaActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Ayuda);
    this.jMenuItem_Opinion.setText("Enviar opinion...");
    this.jMenuItem_Opinion.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jMenuItem_OpinionActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Opinion);
    this.jMenu1.add(this.jSeparator3);
    this.jMenuItem_About.setText("Acerca de ClaveGestión");
    this.jMenuItem_About.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface02Registro.this.jMenuItem_AboutActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_About);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767));
    layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767));
    pack();
  }
  
  private void jMenuItem_SalirActionPerformed(ActionEvent evt) {
    if (JOptionPane.showOptionDialog(null, "El programa no ha terminado de configurarse\n¿Realmente desea salir del programa?", "ClaveGestión", 0, 3, null, new Object[] { " Salir ", " Cancelar " }, "NO") == 0) {
      JOptionPane.showMessageDialog(null, "La próxima vez que lo abra, podrá seguir con la configuración.\nHasta la próxima...", "Configuración Incial", 1);
      System.exit(0);
    } 
  }
  
  private void jMenuItem_ModificarUserActionPerformed(ActionEvent evt) {
    JOptionPane.showMessageDialog(null, "En estos momentos esta opción no está disponible.\nPrimero debe crear un Usuario.", "Crear Usuario", 1);
  }
  
  private void jMenuItem_AboutActionPerformed(ActionEvent evt) {
    JMenuBar.AboutMe();
  }
  
  private void jMenuItem_AyudaActionPerformed(ActionEvent evt) {
    JMenuBar.LinkPDF();
  }
  
  private void jMenuItem_OpinionActionPerformed(ActionEvent evt) {
    JMenuBar.EnviarOpinion();
  }
  
  private void jButton_ResetActionPerformed(ActionEvent evt) {
    this.organizador.reset3(this.jTextField_NameUser, this.jTextField_PassUser, this.jTextField_RePassUser);
  }
  
  private void jButton_CrearUsuarioActionPerformed(ActionEvent evt) {
    if (this.organizador.validarRegistro(this.jTextField_NameUser, this.jTextField_PassUser, this.jTextField_RePassUser))
      try {
        String pasEnco = this.utilities.enco(this.jTextField_PassUser.getText());
        String namEnco = this.utilities.en1100(this.jTextField_NameUser.getText());
        Usuario unUsuario = new Usuario(namEnco, pasEnco);
        this.cUsuarioLogin.registrarUsuario(unUsuario);
        Interface01APP interface01APP = new Interface01APP();
        interface01APP.setVisible(true);
        dispose();
      } catch (Exception ex) {
        Logger.getLogger(Interface02Registro.class.getName()).log(Level.SEVERE, (String)null, ex);
      }  
  }
  
  private void jMenuItem_passGeneratorActionPerformed(ActionEvent evt) {
    JMenuBar.passGenerator();
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Interface02Registro.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(Interface02Registro.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(Interface02Registro.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(Interface02Registro.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Interface02Registro()).setVisible(true);
          }
        });
  }
}
