package vistas;

import controlador.JMenuBar;
import controlador.Organizador;
import controlador.UsuarioLogin;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JSeparator;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import modelos.Usuario;
import tb.controlador.ControlVarGlobal;
import tb.controlador.Utilities;
import tb.vistas.Interface10ENTER;

public class Interface03Login extends JFrame {
  UsuarioLogin cUsuarioLogin = new UsuarioLogin();
  
  Organizador organizador = new Organizador();
  
  ResultSet rs;
  
  LinkedList<Usuario> listaUsuario;
  
  Usuario unUsuario;
  
  Utilities utilities = new Utilities();
  
  private JButton jButton_ModificarUser;
  
  private JButton jButton_login;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  private JLabel jLabel_name;
  
  private JMenu jMenu1;
  
  private JMenu jMenu3;
  
  private JMenuBar jMenuBar1;
  
  private JMenuItem jMenuItem_About;
  
  private JMenuItem jMenuItem_Ayuda;
  
  private JMenuItem jMenuItem_ModificarUser;
  
  private JMenuItem jMenuItem_Opinion;
  
  private JMenuItem jMenuItem_Salir;
  
  private JMenuItem jMenuItem_passGenerator;
  
  private JMenu jMenu_ModificarUsuario;
  
  private JPanel jPanel1;
  
  private JPasswordField jPasswordField_pass;
  
  private JPopupMenu.Separator jSeparator1;
  
  private JSeparator jSeparator2;
  
  private JSeparator jSeparator3;
  
  private JPopupMenu.Separator jSeparator4;
  
  public Interface03Login() {
    initComponents();
    setLocationRelativeTo((Component)null);
    setResizable(false);
    setTitle("ClaveGestión | Haciendo Login");
    this.jLabel_name.setText((String)null);
    this.jPasswordField_pass.setText((String)null);
    prepararLoginUsuario();
  }
  
  private void prepararLoginUsuario() {
    String controlName = null;
    this.listaUsuario = this.cUsuarioLogin.listarUsuario();
    if (this.listaUsuario.size() == 1) {
      controlName = ((Usuario)this.listaUsuario.get(0)).getName();
      this.jLabel_name.setText(controlName);
    } 
  }
  
  private void initComponents() {
    this.jPanel1 = new JPanel();
    this.jLabel1 = new JLabel();
    this.jLabel_name = new JLabel();
    this.jSeparator2 = new JSeparator();
    this.jPasswordField_pass = new JPasswordField();
    this.jButton_login = new JButton();
    this.jSeparator3 = new JSeparator();
    this.jButton_ModificarUser = new JButton();
    this.jLabel2 = new JLabel();
    this.jLabel3 = new JLabel();
    this.jMenuBar1 = new JMenuBar();
    this.jMenu_ModificarUsuario = new JMenu();
    this.jMenuItem_ModificarUser = new JMenuItem();
    this.jSeparator1 = new JPopupMenu.Separator();
    this.jMenuItem_Salir = new JMenuItem();
    this.jMenu3 = new JMenu();
    this.jMenuItem_passGenerator = new JMenuItem();
    this.jMenu1 = new JMenu();
    this.jMenuItem_Ayuda = new JMenuItem();
    this.jMenuItem_Opinion = new JMenuItem();
    this.jSeparator4 = new JPopupMenu.Separator();
    this.jMenuItem_About = new JMenuItem();
    setDefaultCloseOperation(3);
    setMinimumSize(new Dimension(800, 600));
    setPreferredSize(new Dimension(800, 600));
    this.jPanel1.setBackground(new Color(170, 169, 193));
    this.jPanel1.setPreferredSize(new Dimension(800, 600));
    this.jLabel1.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel1.setText("Haz Login en tu cuenta:");
    this.jLabel_name.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel_name.setText("jLabel2");
    this.jPasswordField_pass.setText("jPasswordField1");
    this.jPasswordField_pass.setMaximumSize(new Dimension(115, 27));
    this.jPasswordField_pass.setMinimumSize(new Dimension(115, 27));
    this.jPasswordField_pass.setName("");
    this.jButton_login.setText("Entrar");
    this.jButton_login.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jButton_loginActionPerformed(evt);
          }
        });
    this.jButton_ModificarUser.setText("Cambiar la contraseña");
    this.jButton_ModificarUser.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jButton_ModificarUserActionPerformed(evt);
          }
        });
    this.jLabel2.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel2.setText("Usuario:");
    this.jLabel3.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel3.setText("Contraseña:");
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(91, 91, 91).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jLabel3).addComponent(this.jLabel2))).addGroup(jPanel1Layout.createSequentialGroup().addGap(219, 219, 219).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jButton_ModificarUser).addComponent(this.jButton_login)))).addContainerGap(427, 32767)).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(216, 216, 216).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel_name, -1, -1, 32767).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jPasswordField_pass, -2, 560, -2).addGap(0, 24, 32767)))).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel1, -1, -1, 32767).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jSeparator3, -2, 764, -2).addComponent(this.jSeparator2, -2, 764, -2)).addGap(0, 24, 32767))))).addContainerGap())));
    jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addGap(90, 90, 90).addComponent(this.jLabel2).addGap(18, 18, 18).addComponent(this.jLabel3).addGap(55, 55, 55).addComponent(this.jButton_login).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 298, 32767).addComponent(this.jButton_ModificarUser).addGap(39, 39, 39)).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel1, -2, 34, -2).addGap(37, 37, 37).addComponent(this.jLabel_name, -2, 37, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jPasswordField_pass, -2, -1, -2).addGap(18, 18, 18).addComponent(this.jSeparator2, -2, 10, -2).addGap(91, 91, 91).addComponent(this.jSeparator3, -2, 10, -2).addContainerGap(291, 32767))));
    this.jMenu_ModificarUsuario.setText("Archivo");
    this.jMenuItem_ModificarUser.setText("Modificar la Contraseña de Acceso al Programa");
    this.jMenuItem_ModificarUser.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jMenuItem_ModificarUserActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_ModificarUser);
    this.jMenu_ModificarUsuario.add(this.jSeparator1);
    this.jMenuItem_Salir.setText("Salir");
    this.jMenuItem_Salir.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jMenuItem_SalirActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_Salir);
    this.jMenu3.setText("Herramientas");
    this.jMenuItem_passGenerator.setText("Generador de Contraseñas");
    this.jMenuItem_passGenerator.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jMenuItem_passGeneratorActionPerformed(evt);
          }
        });
    this.jMenu3.add(this.jMenuItem_passGenerator);
    this.jMenu1.setText("Ayuda");
    this.jMenuItem_Ayuda.setText("Ayuda de ClaveGestión");
    this.jMenuItem_Ayuda.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jMenuItem_AyudaActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Ayuda);
    this.jMenuItem_Opinion.setText("Enviar opinión...");
    this.jMenuItem_Opinion.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jMenuItem_OpinionActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Opinion);
    this.jMenu1.add(this.jSeparator4);
    this.jMenuItem_About.setText("Acerca de ClaveGestión");
    this.jMenuItem_About.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface03Login.this.jMenuItem_AboutActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_About);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, 812, 32767));
    layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767));
    pack();
  }
  
  private void jMenuItem_SalirActionPerformed(ActionEvent evt) {
    JMenuBar.salir();
  }
  
  private void jButton_loginActionPerformed(ActionEvent evt) {
    try {
      String pasEnco = this.utilities.enco(this.jPasswordField_pass.getText());
      Usuario logUsuario = new Usuario(this.jLabel_name.getText(), pasEnco);
      if (this.cUsuarioLogin.logearUsuario(logUsuario)) {
        ControlVarGlobal.user = this.jLabel_name.getText();
        Interface10ENTER interface10ENTER = new Interface10ENTER();
        interface10ENTER.setVisible(true);
        dispose();
      } else {
        this.jPasswordField_pass.setText((String)null);
        JOptionPane.showMessageDialog(null, "Contraseña Incorrecta!.\nInténtelo de nuevo.", "Login de Usuario", 0);
      } 
    } catch (Exception ex) {
      Logger.getLogger(Interface03Login.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem_ModificarUserActionPerformed(ActionEvent evt) {
    JMenuBar.modificarUserItem();
    dispose();
  }
  
  private void jButton_ModificarUserActionPerformed(ActionEvent evt) {
    JMenuBar.modificarUserItem();
    dispose();
  }
  
  private void jMenuItem_AboutActionPerformed(ActionEvent evt) {
    JMenuBar.AboutMe();
  }
  
  private void jMenuItem_AyudaActionPerformed(ActionEvent evt) {
    JMenuBar.LinkPDF();
  }
  
  private void jMenuItem_OpinionActionPerformed(ActionEvent evt) {
    JMenuBar.EnviarOpinion();
  }
  
  private void jMenuItem_passGeneratorActionPerformed(ActionEvent evt) {
    JMenuBar.passGenerator();
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Interface03Login.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(Interface03Login.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(Interface03Login.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(Interface03Login.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Interface03Login()).setVisible(true);
          }
        });
  }
}

