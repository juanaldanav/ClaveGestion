package tb.hibernates;

import controlador.JMenuBar;
import java.util.List;
import javax.swing.JOptionPane;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
  private Configuration configuration;
  
  private SessionFactory sessionFactory;
  
  private Session session;
  
  private Transaction transaction;
  
  private Query query;
  
  private List lista;
  
  public HibernateUtil() {
    this.configuration = new Configuration();
    this.configuration.configure("hibernate.cfg.xml");
  }
  
  public void conexionUtil() {
    try {
      this.sessionFactory = this.configuration.buildSessionFactory();
      this.session = this.sessionFactory.openSession();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Conexión.", "Conectando...", 0);
      JMenuBar.operacionNoPermitida();
    } 
  }
  
  public void desconexionUtil() {
    this.session.disconnect();
  }
  
  public void guardarUtil(Object objeto) {
    try {
      this.session.clear();
      this.transaction = this.session.beginTransaction();
      this.session.save(objeto);
      this.transaction.commit();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecución:\n\nEs posible que se haya excedido el límite de 175 carateres por campo.\n\nPor favor revise el contenido.\n\nClaveGestión NO va a Guardar ningún Registro.", "Guardando...", 0);
    } 
  }
  
  public void modificarUtil(Object objeto) {
    try {
      this.session.clear();
      this.transaction = this.session.beginTransaction();
      this.session.update(objeto);
      this.transaction.commit();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecución:\n\nEs posible que se haya excedido el límite de 175 carateres por campo.\n\nPor favor revise el contenido.\n\nClaveGestión NO va a Modificar ningún Registro.", "Modificando...", 0);
      JMenuBar.operacionNoPermitida();
    } 
  }
  
  public void eliminarUtil(Object objeto) {
    try {
      this.session.clear();
      this.transaction = this.session.beginTransaction();
      this.session.delete(objeto);
      this.transaction.commit();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecución.", "Eliminando...", 0);
      JMenuBar.operacionNoPermitida();
    } 
  }
  
  public List listarUtil(Class clase) {
    this.lista = null;
    try {
      this.session.clear();
      this.query = this.session.createQuery("FROM " + clase.getName());
      this.lista = this.query.list();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecución.", "Listando...", 0);
      JMenuBar.operacionNoPermitida();
    } 
    return this.lista;
  }
}


