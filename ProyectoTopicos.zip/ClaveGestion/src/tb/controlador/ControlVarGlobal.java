package tb.controlador;

public class ControlVarGlobal {
  public static String user;
  
  public static String tabla;
  
  public static String iee = "AES";
  
  public static String ire = "AES/ECB/PKCS5Padding";
  
  public static String rut = "ClaveGestion_DB/license.dat";
}


