package tb.controlador;

import java.util.List;
import javax.swing.JOptionPane;
import tb.hibernates.HibernateUtil;
import tb.modelos.TB_Banca;
import tb.modelos.TB_Correo;
import tb.modelos.TB_Datos01;
import tb.modelos.TB_Datos02;
import tb.modelos.TB_Datos03;
import tb.modelos.TB_Educacion;
import tb.modelos.TB_Hosting;
import tb.modelos.TB_Nube;
import tb.modelos.TB_Ocio;
import tb.modelos.TB_Proveedores;
import tb.modelos.TB_RedesSociales;
import tb.modelos.TB_Sites;
import tb.modelos.TB_Tiendas;
import tb.modelos.TB_Trabajo;

public class ControlTABLAS {
  public HibernateUtil unHibernateUtil = new HibernateUtil();
  
  public void guardarRegistroTablas(Object objeto) {
    try {
      this.unHibernateUtil.conexionUtil();
      this.unHibernateUtil.guardarUtil(objeto);
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecución.", "Guardar Registro", 0);
    } 
    this.unHibernateUtil.desconexionUtil();
  }
  
  public void modificarRegistroTablas(Object objeto) {
    if (JOptionPane.showOptionDialog(null, "Esta operación modifica un Registro\nEl Registro será sobrescrito con los nuevos datos.\nLos datos anteriores se perderán.", "Modificar Registro", 0, 3, null, new Object[] { " Modificar ", " Cancelar " }, "NO") == 0) {
      try {
        this.unHibernateUtil.conexionUtil();
        this.unHibernateUtil.modificarUtil(objeto);
        JOptionPane.showMessageDialog(null, "Se ha modificado el Registro.", "Modificar Registro", 1);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error de Ejecución.", "Modificar Registro", 0);
      } 
    } else {
      JOptionPane.showMessageDialog(null, "Operación Cancelada.\nNo se ha modificado ningún Registro.", "Modificar Registro", 1);
    } 
    this.unHibernateUtil.desconexionUtil();
  }
  
  public void eliminarRegistroTablas(Object objeto) {
    if (JOptionPane.showOptionDialog(null, "Esta operación elimina un Registro.\nEl registro será eliminado de forma permanente.\nLos datos no podrán ser recuperados.", "Eliminar Registro", 0, 3, null, new Object[] { " Eliminar ", " Cancelar " }, "NO") == 0) {
      try {
        this.unHibernateUtil.conexionUtil();
        this.unHibernateUtil.eliminarUtil(objeto);
        JOptionPane.showMessageDialog(null, "Se ha eliminado el Registro.", "Eliminar Registro", 1);
      } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error de Ejecución.", "Eliminar Registro", 0);
      } 
    } else {
      JOptionPane.showMessageDialog(null, "Operación Cancelada.\nNo se ha eliminado ningún Registro.", "Eliminar Registro", 1);
    } 
    this.unHibernateUtil.desconexionUtil();
  }
  
  public List<TB_Correo> controlTBListarCorreo() {
    List<TB_Correo> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Correo.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_RedesSociales> controlTBListarRedesSociales() {
    List<TB_RedesSociales> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_RedesSociales.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Nube> controlTBListarAlmaceNube() {
    List<TB_Nube> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Nube.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Proveedores> controlTBListarProveedores() {
    List<TB_Proveedores> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Proveedores.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Tiendas> controlTBListarTiendas() {
    List<TB_Tiendas> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Tiendas.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Ocio> controlTBListarOcio() {
    List<TB_Ocio> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Ocio.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Educacion> controlTBListarEducacion() {
    List<TB_Educacion> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Educacion.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Banca> controlTBListarBanca() {
    List<TB_Banca> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Banca.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Trabajo> controlTBListarTrabajo() {
    List<TB_Trabajo> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Trabajo.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Hosting> controlTBListarHosting() {
    List<TB_Hosting> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Hosting.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Sites> controlTBListarSites() {
    List<TB_Sites> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Sites.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Datos01> controlTBListarDatos01() {
    List<TB_Datos01> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Datos01.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Datos02> controlTBListarDatos02() {
    List<TB_Datos02> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Datos02.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
  
  public List<TB_Datos03> controlTBListarDatos03() {
    List<TB_Datos03> lista = null;
    try {
      this.unHibernateUtil.conexionUtil();
      lista = this.unHibernateUtil.listarUtil(TB_Datos03.class);
    } catch (Exception exception) {}
    this.unHibernateUtil.desconexionUtil();
    return lista;
  }
}


