package tb.controlador;

import controlador.JMenuBar;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Base64;

public class Utilities {
  public static Key Llav;
  
  public String enco(String texto) throws Exception {
    MessageDigest md = MessageDigest.getInstance("SHA-256");
    md.update(texto.getBytes());
    byte[] digest = md.digest();
    byte[] enco = Base64.encodeBase64(digest);
    return new String(enco);
  }
  
  public void genLi0000() throws Exception {
    KeyGenerator keyGenerator = KeyGenerator.getInstance(ControlVarGlobal.iee);
    SecureRandom secureRandom = new SecureRandom();
    keyGenerator.init(128, secureRandom);
    Key key = keyGenerator.generateKey();
    saveLi0000(key);
  }
  
  private void saveLi0000(Key key) throws Exception {
    byte[] KeyBytes = key.getEncoded();
    try (FileOutputStream fos = new FileOutputStream(ControlVarGlobal.rut)) {
      fos.write(KeyBytes);
    } catch (IOException e) {
      JMenuBar.operacionNoPermitida();
    } 
  }
  
  public void genLlav0100() throws Exception {
    Llav = loadLlav0100();
  }
  
  private Key loadLlav0100() throws IOException {
    FileInputStream fis = null;
    try {
      fis = new FileInputStream(ControlVarGlobal.rut);
    } catch (FileNotFoundException ex) {
      Logger.getLogger(Utilities.class.getName()).log(Level.SEVERE, (String)null, ex);
      JMenuBar.operacionNoPermitida();
    } 
    int numBtyes = fis.available();
    byte[] bytes = new byte[numBtyes];
    Key key = new SecretKeySpec(bytes, ControlVarGlobal.iee);
    fis.read(bytes);
    fis.close();
    return key;
  }
  
  public String en1100(String texto) throws Exception {
    Cipher cipher = Cipher.getInstance(ControlVarGlobal.ire);
    cipher.init(1, Llav);
    byte[] encrip = cipher.doFinal(texto.getBytes());
    return new String(Base64.encodeBase64(encrip));
  }
  
  public String des1100(String texto) throws Exception {
    Cipher cipher = Cipher.getInstance(ControlVarGlobal.ire);
    byte[] enc = Base64.decodeBase64(texto);
    cipher.init(2, Llav);
    byte[] decrypted = cipher.doFinal(enc);
    return new String(decrypted);
  }
}

