package tb.modelos;

public class TB_Datos01 {
  public static final String[] Columns = new String[] { 
      "ID", "Campo 01", "Campo 02", "Campo 03", "Campo 04", "Campo 05", "Campo 06", "Campo 07", "Campo 08", "Campo 09", 
      "Campo 10" };
  
  public static final String[] ColumnsEdic = new String[] { "Campo 01:", "Campo 02:", "Campo 03:", "Campo 04:", "Campo 05:", "Campo 06:", "Campo 07:", "Campo 08:", "Campo 09:", "Campo 10:" };
  
  private int id;
  
  private String campo01;
  
  private String campo02;
  
  private String campo03;
  
  private String campo04;
  
  private String campo05;
  
  private String campo06;
  
  private String campo07;
  
  private String campo08;
  
  private String campo09;
  
  private String campo10;
  
  public TB_Datos01() {}
  
  public TB_Datos01(String campo01, String campo02, String campo03, String campo04, String campo05, String campo06, String campo07, String campo08, String campo09, String campo10) {
    this.campo01 = campo01;
    this.campo02 = campo02;
    this.campo03 = campo03;
    this.campo04 = campo04;
    this.campo05 = campo05;
    this.campo06 = campo06;
    this.campo07 = campo07;
    this.campo08 = campo08;
    this.campo09 = campo09;
    this.campo10 = campo10;
  }
  
  public TB_Datos01(int id, String campo01, String campo02, String campo03, String campo04, String campo05, String campo06, String campo07, String campo08, String campo09, String campo10) {
    this.id = id;
    this.campo01 = campo01;
    this.campo02 = campo02;
    this.campo03 = campo03;
    this.campo04 = campo04;
    this.campo05 = campo05;
    this.campo06 = campo06;
    this.campo07 = campo07;
    this.campo08 = campo08;
    this.campo09 = campo09;
    this.campo10 = campo10;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getCampo01() {
    return this.campo01;
  }
  
  public void setCampo01(String campo01) {
    this.campo01 = campo01;
  }
  
  public String getCampo02() {
    return this.campo02;
  }
  
  public void setCampo02(String campo02) {
    this.campo02 = campo02;
  }
  
  public String getCampo03() {
    return this.campo03;
  }
  
  public void setCampo03(String campo03) {
    this.campo03 = campo03;
  }
  
  public String getCampo04() {
    return this.campo04;
  }
  
  public void setCampo04(String campo04) {
    this.campo04 = campo04;
  }
  
  public String getCampo05() {
    return this.campo05;
  }
  
  public void setCampo05(String campo05) {
    this.campo05 = campo05;
  }
  
  public String getCampo06() {
    return this.campo06;
  }
  
  public void setCampo06(String campo06) {
    this.campo06 = campo06;
  }
  
  public String getCampo07() {
    return this.campo07;
  }
  
  public void setCampo07(String campo07) {
    this.campo07 = campo07;
  }
  
  public String getCampo08() {
    return this.campo08;
  }
  
  public void setCampo08(String campo08) {
    this.campo08 = campo08;
  }
  
  public String getCampo09() {
    return this.campo09;
  }
  
  public void setCampo09(String campo09) {
    this.campo09 = campo09;
  }
  
  public String getCampo10() {
    return this.campo10;
  }
  
  public void setCampo10(String campo10) {
    this.campo10 = campo10;
  }
}


