package tb.modelos;

public class TB_Ocio {
  public static final String[] Columns = new String[] { "ID", "Empresa", "URL", "Usuario", "Correo Electrónico", "Contraseña", "Nombre", "Teléfono" };
  
  public static final String[] ColumnsEdic = new String[] { "Empresa:", "URL, dirección en el navegador:", "Nombre de Usuario:", "Correo Electrónico:", "Contraseña:", "Nombre y Apellidos:", "Teléfono:" };
  
  private int id;
  
  private String server;
  
  private String url;
  
  private String user;
  
  private String email;
  
  private String clave;
  
  private String name;
  
  private String phone;
  
  public TB_Ocio() {}
  
  public TB_Ocio(String server, String url, String user, String email, String clave, String name, String phone) {
    this.server = server;
    this.url = url;
    this.user = user;
    this.email = email;
    this.clave = clave;
    this.name = name;
    this.phone = phone;
  }
  
  public TB_Ocio(int id, String server, String url, String user, String email, String clave, String name, String phone) {
    this.id = id;
    this.server = server;
    this.url = url;
    this.user = user;
    this.email = email;
    this.clave = clave;
    this.name = name;
    this.phone = phone;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getServer() {
    return this.server;
  }
  
  public void setServer(String server) {
    this.server = server;
  }
  
  public String getUrl() {
    return this.url;
  }
  
  public void setUrl(String url) {
    this.url = url;
  }
  
  public String getUser() {
    return this.user;
  }
  
  public void setUser(String user) {
    this.user = user;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getClave() {
    return this.clave;
  }
  
  public void setClave(String clave) {
    this.clave = clave;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public void setPhone(String phone) {
    this.phone = phone;
  }
}

