package tb.modelos;

public class TB_Banca {
  public static final String[] Columns = new String[] { "ID", "Empresa", "URL", "Usuario", "Correo Electrónico", "Contraseña 01", "Contraseña 02", "Firma 01", "Firma 02", "Teléfono Incidencias" };
  
  public static final String[] ColumnsEdic = new String[] { "Empresa:", "URL, dirección en el navegador:", "Nombre de Usuario:", "Correo Electrónico:", "Contraseña 01:", "Contraseña 02:", "Firma Electrónica 01:", "Firma Electrónica 02:", "Teléfono de Incidencias de la Companía:" };
  
  private int id;
  
  private String server;
  
  private String url;
  
  private String user;
  
  private String email;
  
  private String clave01;
  
  private String clave02;
  
  private String firma01;
  
  private String firma02;
  
  private String phone;
  
  public TB_Banca() {}
  
  public TB_Banca(String server, String url, String user, String email, String clave01, String clave02, String firma01, String firma02, String phone) {
    this.server = server;
    this.url = url;
    this.user = user;
    this.email = email;
    this.clave01 = clave01;
    this.clave02 = clave02;
    this.firma01 = firma01;
    this.firma02 = firma02;
    this.phone = phone;
  }
  
  public TB_Banca(int id, String server, String url, String user, String email, String clave01, String clave02, String firma01, String firma02, String phone) {
    this.id = id;
    this.server = server;
    this.url = url;
    this.user = user;
    this.email = email;
    this.clave01 = clave01;
    this.clave02 = clave02;
    this.firma01 = firma01;
    this.firma02 = firma02;
    this.phone = phone;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getServer() {
    return this.server;
  }
  
  public void setServer(String server) {
    this.server = server;
  }
  
  public String getUrl() {
    return this.url;
  }
  
  public void setUrl(String url) {
    this.url = url;
  }
  
  public String getUser() {
    return this.user;
  }
  
  public void setUser(String user) {
    this.user = user;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getClave01() {
    return this.clave01;
  }
  
  public void setClave01(String clave01) {
    this.clave01 = clave01;
  }
  
  public String getClave02() {
    return this.clave02;
  }
  
  public void setClave02(String clave02) {
    this.clave02 = clave02;
  }
  
  public String getFirma01() {
    return this.firma01;
  }
  
  public void setFirma01(String firma01) {
    this.firma01 = firma01;
  }
  
  public String getFirma02() {
    return this.firma02;
  }
  
  public void setFirma02(String firma02) {
    this.firma02 = firma02;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public void setPhone(String phone) {
    this.phone = phone;
  }
}


