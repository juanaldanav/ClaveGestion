package tb.modelos;

public class TB_Correo {
  public static final String[] Columns = new String[] { "ID", "Nombre de Usuario", "Servidor de Correo", "Dirección de Correo", "Contraseña", "Email de Recuperación", "Teléfono de Recuperación" };
  
  public static final String[] ColumnsEdic = new String[] { "Nombre de Usuario, para el correo:", "Servidor de Correo, por ejemplo GMail:", "Dirección de Correo:", "Contraseña:", "Email de Recuperación, si se tiene:", "Teléfono de Recuperación, si se tiene:" };
  
  private int id;
  
  private String name;
  
  private String server;
  
  private String email;
  
  private String clave;
  
  private String cuentaRecup;
  
  private String telfRecup;
  
  public TB_Correo() {}
  
  public TB_Correo(String name, String server, String email, String clave, String cuentaRecup, String telfRecup) {
    this.name = name;
    this.server = server;
    this.email = email;
    this.clave = clave;
    this.cuentaRecup = cuentaRecup;
    this.telfRecup = telfRecup;
  }
  
  public TB_Correo(int id, String name, String server, String email, String clave, String cuentaRecup, String telfRecup) {
    this.id = id;
    this.name = name;
    this.server = server;
    this.email = email;
    this.clave = clave;
    this.cuentaRecup = cuentaRecup;
    this.telfRecup = telfRecup;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getServer() {
    return this.server;
  }
  
  public void setServer(String server) {
    this.server = server;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getClave() {
    return this.clave;
  }
  
  public void setClave(String clave) {
    this.clave = clave;
  }
  
  public String getCuentaRecup() {
    return this.cuentaRecup;
  }
  
  public void setCuentaRecup(String cuentaRecup) {
    this.cuentaRecup = cuentaRecup;
  }
  
  public String getTelfRecup() {
    return this.telfRecup;
  }
  
  public void setTelfRecup(String telfRecup) {
    this.telfRecup = telfRecup;
  }
}


