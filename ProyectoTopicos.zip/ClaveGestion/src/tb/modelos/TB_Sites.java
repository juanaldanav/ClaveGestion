package tb.modelos;

public class TB_Sites {
  public static final String[] Columns = new String[] { 
      "ID", "URL Dominio", "URL Administración", "Usuario", "Contraseña", "Correo Electrónico", "Privilegios", "Servidor FTP", "Base de Datos", "Usuario", 
      "Contraseña" };
  
  public static final String[] ColumnsEdic = new String[] { "URL del Dominio:", "URL de la Administración:", "Nombre de Usuario:", "Contraseña:", "Correo Electrónico:", "Privilegios Administrativos:", "URL de la Base de Datos o del Servidor FTP:", "Nombre de la Base de Datos:", "Nombre de Usuario en la Base de Datos / FTP:", "Contraseña para la Base de Datos / FTP:" };
  
  private int id;
  
  private String url;
  
  private String urlAdmin;
  
  private String user;
  
  private String clave;
  
  private String email;
  
  private String privil;
  
  private String ftp;
  
  private String db;
  
  private String userDB;
  
  private String claveDB;
  
  public TB_Sites() {}
  
  public TB_Sites(String url, String urlAdmin, String user, String clave, String email, String privil, String ftp, String db, String userDB, String claveDB) {
    this.url = url;
    this.urlAdmin = urlAdmin;
    this.user = user;
    this.clave = clave;
    this.email = email;
    this.privil = privil;
    this.ftp = ftp;
    this.db = db;
    this.userDB = userDB;
    this.claveDB = claveDB;
  }
  
  public TB_Sites(int id, String url, String urlAdmin, String user, String clave, String email, String privil, String ftp, String db, String userDB, String claveDB) {
    this.id = id;
    this.url = url;
    this.urlAdmin = urlAdmin;
    this.user = user;
    this.clave = clave;
    this.email = email;
    this.privil = privil;
    this.ftp = ftp;
    this.db = db;
    this.userDB = userDB;
    this.claveDB = claveDB;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getUrl() {
    return this.url;
  }
  
  public void setUrl(String url) {
    this.url = url;
  }
  
  public String getUrlAdmin() {
    return this.urlAdmin;
  }
  
  public void setUrlAdmin(String urlAdmin) {
    this.urlAdmin = urlAdmin;
  }
  
  public String getUser() {
    return this.user;
  }
  
  public void setUser(String user) {
    this.user = user;
  }
  
  public String getClave() {
    return this.clave;
  }
  
  public void setClave(String clave) {
    this.clave = clave;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getPrivil() {
    return this.privil;
  }
  
  public void setPrivil(String privil) {
    this.privil = privil;
  }
  
  public String getFtp() {
    return this.ftp;
  }
  
  public void setFtp(String ftp) {
    this.ftp = ftp;
  }
  
  public String getDb() {
    return this.db;
  }
  
  public void setDb(String db) {
    this.db = db;
  }
  
  public String getUserDB() {
    return this.userDB;
  }
  
  public void setUserDB(String userDB) {
    this.userDB = userDB;
  }
  
  public String getClaveDB() {
    return this.claveDB;
  }
  
  public void setClaveDB(String claveDB) {
    this.claveDB = claveDB;
  }
}

