package tb.modelos;

public class TB_RedesSociales {
  public static final String[] Columns = new String[] { "ID", "Servidor", "Usuario", "Dirección de Correo", "Contraseña", "Teléfono" };
  
  public static final String[] ColumnsEdic = new String[] { "Nombre del Servidor, por ejemplo FaceBook:", "Usuario:", "Dirección de Correo:", "Contraseña:", "Teléfono, si se tiene añadido a la cuenta:" };
  
  private int id;
  
  private String server;
  
  private String user;
  
  private String email;
  
  private String clave;
  
  private String phone;
  
  public TB_RedesSociales() {}
  
  public TB_RedesSociales(String server, String user, String email, String clave, String phone) {
    this.server = server;
    this.user = user;
    this.email = email;
    this.clave = clave;
    this.phone = phone;
  }
  
  public TB_RedesSociales(int id, String server, String user, String email, String clave, String phone) {
    this.id = id;
    this.server = server;
    this.user = user;
    this.email = email;
    this.clave = clave;
    this.phone = phone;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getServer() {
    return this.server;
  }
  
  public void setServer(String server) {
    this.server = server;
  }
  
  public String getUser() {
    return this.user;
  }
  
  public void setUser(String user) {
    this.user = user;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getClave() {
    return this.clave;
  }
  
  public void setClave(String clave) {
    this.clave = clave;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public void setPhone(String phone) {
    this.phone = phone;
  }
}
