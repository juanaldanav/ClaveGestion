package tb.modelos;

public class TB_Trabajo {
  public static final String[] Columns = new String[] { "ID", "Empresa", "URL", "Usuario", "Correo Electrónico", "Contraseña", "Nombre", "Dirección y CP", "Teléfono", "Fecha" };
  
  public static final String[] ColumnsEdic = new String[] { "Empresa:", "URL, dirección en el navegador:", "Nombre de Usuario:", "Correo Electrónico:", "Contraseña:", "Nombre y Apellidos:", "Dirección, Ciudad y CP:", "Teléfono:", "Fecha actualización:" };
  
  private int id;
  
  private String server;
  
  private String url;
  
  private String user;
  
  private String email;
  
  private String clave;
  
  private String name;
  
  private String address;
  
  private String phone;
  
  private String date;
  
  public TB_Trabajo() {}
  
  public TB_Trabajo(String server, String url, String user, String email, String clave, String name, String address, String phone, String date) {
    this.server = server;
    this.url = url;
    this.user = user;
    this.email = email;
    this.clave = clave;
    this.name = name;
    this.address = address;
    this.phone = phone;
    this.date = date;
  }
  
  public TB_Trabajo(int id, String server, String url, String user, String email, String clave, String name, String address, String phone, String date) {
    this.id = id;
    this.server = server;
    this.url = url;
    this.user = user;
    this.email = email;
    this.clave = clave;
    this.name = name;
    this.address = address;
    this.phone = phone;
    this.date = date;
  }
  
  public int getId() {
    return this.id;
  }
  
  public void setId(int id) {
    this.id = id;
  }
  
  public String getServer() {
    return this.server;
  }
  
  public void setServer(String server) {
    this.server = server;
  }
  
  public String getUrl() {
    return this.url;
  }
  
  public void setUrl(String url) {
    this.url = url;
  }
  
  public String getUser() {
    return this.user;
  }
  
  public void setUser(String user) {
    this.user = user;
  }
  
  public String getEmail() {
    return this.email;
  }
  
  public void setEmail(String email) {
    this.email = email;
  }
  
  public String getClave() {
    return this.clave;
  }
  
  public void setClave(String clave) {
    this.clave = clave;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getAddress() {
    return this.address;
  }
  
  public void setAddress(String address) {
    this.address = address;
  }
  
  public String getPhone() {
    return this.phone;
  }
  
  public void setPhone(String phone) {
    this.phone = phone;
  }
  
  public String getDate() {
    return this.date;
  }
  
  public void setDate(String date) {
    this.date = date;
  }
}

