package tb.vistas;

import controlador.JMenuBar;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import tb.controlador.ControlVarGlobal;

public class Interface10ENTER extends JFrame {
  private JButton jButton_Banca;
  
  private JButton jButton_Correos;
  
  private JButton jButton_Datos01;
  
  private JButton jButton_Datos02;
  
  private JButton jButton_Datos03;
  
  private JButton jButton_Educacion;
  
  private JButton jButton_Hosting;
  
  private JButton jButton_Nube;
  
  private JButton jButton_Ocio;
  
  private JButton jButton_Proveedores;
  
  private JButton jButton_RedesSociales;
  
  private JButton jButton_Sites;
  
  private JButton jButton_Tiendas;
  
  private JButton jButton_Trabajo;
  
  private JLabel jLabel1;
  
  private JLabel jLabel_10ENTER;
  
  private JMenu jMenu1;
  
  private JMenu jMenu2;
  
  private JMenu jMenu3;
  
  private JMenuBar jMenuBar1;
  
  private JMenuItem jMenuItem1;
  
  private JMenuItem jMenuItem10;
  
  private JMenuItem jMenuItem11;
  
  private JMenuItem jMenuItem12;
  
  private JMenuItem jMenuItem13;
  
  private JMenuItem jMenuItem14;
  
  private JMenuItem jMenuItem15;
  
  private JMenuItem jMenuItem2;
  
  private JMenuItem jMenuItem4;
  
  private JMenuItem jMenuItem5;
  
  private JMenuItem jMenuItem6;
  
  private JMenuItem jMenuItem7;
  
  private JMenuItem jMenuItem8;
  
  private JMenuItem jMenuItem9;
  
  private JMenuItem jMenuItem_10ENTER;
  
  private JMenuItem jMenuItem_About;
  
  private JMenuItem jMenuItem_Ayuda;
  
  private JMenuItem jMenuItem_ModificarUser;
  
  private JMenuItem jMenuItem_Opinion;
  
  private JMenuItem jMenuItem_Salir;
  
  private JMenuItem jMenuItem_passGenerator;
  
  private JMenu jMenu_ModificarUsuario;
  
  private JPanel jPanel1;
  
  private JPanel jPanel2;
  
  private JPanel jPanel3;
  
  private JScrollPane jScrollPane1;
  
  private JPopupMenu.Separator jSeparator1;
  
  private JSeparator jSeparator2;
  
  private JSeparator jSeparator3;
  
  private JPopupMenu.Separator jSeparator4;
  
  private JPopupMenu.Separator jSeparator5;
  
  private JPopupMenu.Separator jSeparator6;
  
  private JPopupMenu.Separator jSeparator7;
  
  private JTextArea jTextArea1;
  
  public Interface10ENTER() {
    initComponents();
    setLocationRelativeTo(null);
    setResizable(false);
    setTitle("ClaveGestión | Menú Principal | Usuario: " + ControlVarGlobal.user);
    ControlVarGlobal.tabla = null;
    this.jLabel_10ENTER.setText("Ha iniciado sesión con el Usuario: " + ControlVarGlobal.user);
  }
  
  private void resetjTextArea1() {
    this.jTextArea1.setText("\tSeleccione la Tabla en función del tipo de datos que va a registrar. Por ejemplo:\n Si va a guardar un correo, presione el botón \"Cuentas de Correos\".\n Si va a guardar la clave del Facebook, presione el Botón de \"Cuentas de Redes Sociales\".\n\n\tAsí tendrá su información más organizada y accesible.");
  }
  
  private void linkTabla(String tabla) throws Exception {
    ControlVarGlobal.tabla = tabla;
    JMenuBar.Select100ListarTabla();
    dispose();
  }
  
  private void initComponents() {
    this.jPanel3 = new JPanel();
    this.jLabel_10ENTER = new JLabel();
    this.jSeparator2 = new JSeparator();
    this.jSeparator3 = new JSeparator();
    this.jScrollPane1 = new JScrollPane();
    this.jTextArea1 = new JTextArea();
    this.jLabel1 = new JLabel();
    this.jPanel1 = new JPanel();
    this.jButton_Correos = new JButton();
    this.jButton_RedesSociales = new JButton();
    this.jButton_Nube = new JButton();
    this.jButton_Proveedores = new JButton();
    this.jButton_Tiendas = new JButton();
    this.jButton_Ocio = new JButton();
    this.jButton_Educacion = new JButton();
    this.jPanel2 = new JPanel();
    this.jButton_Banca = new JButton();
    this.jButton_Trabajo = new JButton();
    this.jButton_Hosting = new JButton();
    this.jButton_Sites = new JButton();
    this.jButton_Datos03 = new JButton();
    this.jButton_Datos02 = new JButton();
    this.jButton_Datos01 = new JButton();
    this.jMenuBar1 = new JMenuBar();
    this.jMenu_ModificarUsuario = new JMenu();
    this.jMenuItem_ModificarUser = new JMenuItem();
    this.jSeparator1 = new JPopupMenu.Separator();
    this.jMenuItem_Salir = new JMenuItem();
    this.jMenu2 = new JMenu();
    this.jMenuItem_10ENTER = new JMenuItem();
    this.jSeparator7 = new JPopupMenu.Separator();
    this.jSeparator5 = new JPopupMenu.Separator();
    this.jMenuItem1 = new JMenuItem();
    this.jMenuItem2 = new JMenuItem();
    this.jMenuItem4 = new JMenuItem();
    this.jMenuItem5 = new JMenuItem();
    this.jMenuItem6 = new JMenuItem();
    this.jMenuItem7 = new JMenuItem();
    this.jMenuItem8 = new JMenuItem();
    this.jSeparator6 = new JPopupMenu.Separator();
    this.jMenuItem9 = new JMenuItem();
    this.jMenuItem10 = new JMenuItem();
    this.jMenuItem11 = new JMenuItem();
    this.jMenuItem12 = new JMenuItem();
    this.jMenuItem13 = new JMenuItem();
    this.jMenuItem14 = new JMenuItem();
    this.jMenuItem15 = new JMenuItem();
    this.jMenu3 = new JMenu();
    this.jMenuItem_passGenerator = new JMenuItem();
    this.jMenu1 = new JMenu();
    this.jMenuItem_Ayuda = new JMenuItem();
    this.jMenuItem_Opinion = new JMenuItem();
    this.jSeparator4 = new JPopupMenu.Separator();
    this.jMenuItem_About = new JMenuItem();
    setDefaultCloseOperation(3);
    setMinimumSize(new Dimension(800, 600));
    this.jPanel3.setBackground(new Color(229, 228, 243));
    this.jPanel3.setMaximumSize((Dimension)null);
    this.jPanel3.setMinimumSize(new Dimension(800, 600));
    this.jPanel3.setPreferredSize(new Dimension(800, 600));
    this.jLabel_10ENTER.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel_10ENTER.setText("jLabel1");
    this.jTextArea1.setEditable(false);
    this.jTextArea1.setColumns(20);
    this.jTextArea1.setRows(5);
    this.jTextArea1.setText("\tSeleccione la Tabla en función del tipo de datos que va a registrar. Por ejemplo:\n Si va a guardar un correo, presione el botón \"Cuentas de Correos\".\n Si va a guardar la clave del Facebook, presione el Botón de \"Cuentas de Redes Sociales\".\n\n\tAsí tendrá su información organizada y accesible.");
    this.jScrollPane1.setViewportView(this.jTextArea1);
    this.jLabel1.setFont(new Font("Ubuntu", 1, 15));
    this.jLabel1.setText("Selecciona un Tipo de Tabla:");
    this.jPanel1.setBackground(new Color(229, 228, 243));
    this.jButton_Correos.setText("Cuentas de Correos ");
    this.jButton_Correos.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_CorreosMouseMoved(evt);
          }
        });
    this.jButton_Correos.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_CorreosMouseExited(evt);
          }
        });
    this.jButton_Correos.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_CorreosActionPerformed(evt);
          }
        });
    this.jButton_RedesSociales.setText("Cuentas de Redes Sociales");
    this.jButton_RedesSociales.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_RedesSocialesMouseMoved(evt);
          }
        });
    this.jButton_RedesSociales.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_RedesSocialesMouseExited(evt);
          }
        });
    this.jButton_RedesSociales.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_RedesSocialesActionPerformed(evt);
          }
        });
    this.jButton_Nube.setText("Almacenamiento en la Nube");
    this.jButton_Nube.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_NubeMouseMoved(evt);
          }
        });
    this.jButton_Nube.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_NubeMouseExited(evt);
          }
        });
    this.jButton_Nube.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_NubeActionPerformed(evt);
          }
        });
    this.jButton_Proveedores.setText("Portales de Proveedores");
    this.jButton_Proveedores.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_ProveedoresMouseMoved(evt);
          }
        });
    this.jButton_Proveedores.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_ProveedoresMouseExited(evt);
          }
        });
    this.jButton_Proveedores.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_ProveedoresActionPerformed(evt);
          }
        });
    this.jButton_Tiendas.setText("Tiendas OnLine");
    this.jButton_Tiendas.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_TiendasMouseMoved(evt);
          }
        });
    this.jButton_Tiendas.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_TiendasMouseExited(evt);
          }
        });
    this.jButton_Tiendas.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_TiendasActionPerformed(evt);
          }
        });
    this.jButton_Ocio.setText("Portales de Ocio");
    this.jButton_Ocio.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_OcioMouseMoved(evt);
          }
        });
    this.jButton_Ocio.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_OcioMouseExited(evt);
          }
        });
    this.jButton_Ocio.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_OcioActionPerformed(evt);
          }
        });
    this.jButton_Educacion.setText("Plataformas de Educación");
    this.jButton_Educacion.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_EducacionMouseMoved(evt);
          }
        });
    this.jButton_Educacion.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_EducacionMouseExited(evt);
          }
        });
    this.jButton_Educacion.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_EducacionActionPerformed(evt);
          }
        });
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jButton_Correos).addComponent(this.jButton_RedesSociales).addComponent(this.jButton_Nube).addComponent(this.jButton_Proveedores).addComponent(this.jButton_Tiendas).addComponent(this.jButton_Ocio).addComponent(this.jButton_Educacion)).addGap(0, 190, 32767)));
    jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jButton_Correos).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_RedesSociales).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Nube).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Proveedores).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Tiendas).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Ocio).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Educacion).addGap(0, 88, 32767)));
    this.jPanel2.setBackground(new Color(229, 228, 243));
    this.jButton_Banca.setText("Banca OnLine");
    this.jButton_Banca.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_BancaMouseMoved(evt);
          }
        });
    this.jButton_Banca.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_BancaMouseExited(evt);
          }
        });
    this.jButton_Banca.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_BancaActionPerformed(evt);
          }
        });
    this.jButton_Trabajo.setText("Plataformas de Trabajo");
    this.jButton_Trabajo.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_TrabajoMouseMoved(evt);
          }
        });
    this.jButton_Trabajo.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_TrabajoMouseExited(evt);
          }
        });
    this.jButton_Trabajo.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_TrabajoActionPerformed(evt);
          }
        });
    this.jButton_Hosting.setText("Alojamiento Web");
    this.jButton_Hosting.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_HostingMouseMoved(evt);
          }
        });
    this.jButton_Hosting.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_HostingMouseExited(evt);
          }
        });
    this.jButton_Hosting.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_HostingActionPerformed(evt);
          }
        });
    this.jButton_Sites.setText("Administración Web");
    this.jButton_Sites.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_SitesMouseMoved(evt);
          }
        });
    this.jButton_Sites.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_SitesMouseExited(evt);
          }
        });
    this.jButton_Sites.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_SitesActionPerformed(evt);
          }
        });
    this.jButton_Datos03.setText("Datos 03");
    this.jButton_Datos03.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_Datos03MouseMoved(evt);
          }
        });
    this.jButton_Datos03.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_Datos03MouseExited(evt);
          }
        });
    this.jButton_Datos03.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_Datos03ActionPerformed(evt);
          }
        });
    this.jButton_Datos02.setText("Datos 02");
    this.jButton_Datos02.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_Datos02MouseMoved(evt);
          }
        });
    this.jButton_Datos02.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_Datos02MouseExited(evt);
          }
        });
    this.jButton_Datos02.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_Datos02ActionPerformed(evt);
          }
        });
    this.jButton_Datos01.setText("Datos 01");
    this.jButton_Datos01.addMouseMotionListener(new MouseMotionAdapter() {
          public void mouseMoved(MouseEvent evt) {
            Interface10ENTER.this.jButton_Datos01MouseMoved(evt);
          }
        });
    this.jButton_Datos01.addMouseListener(new MouseAdapter() {
          public void mouseExited(MouseEvent evt) {
            Interface10ENTER.this.jButton_Datos01MouseExited(evt);
          }
        });
    this.jButton_Datos01.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jButton_Datos01ActionPerformed(evt);
          }
        });
    GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
    this.jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jButton_Banca).addComponent(this.jButton_Trabajo).addComponent(this.jButton_Hosting).addComponent(this.jButton_Sites).addComponent(this.jButton_Datos03).addComponent(this.jButton_Datos02).addComponent(this.jButton_Datos01)).addGap(0, 316, 32767)));
    jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jButton_Banca).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Trabajo).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Hosting).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Sites).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Datos01).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Datos02).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton_Datos03).addContainerGap(88, 32767)));
    GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
    this.jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -1, 1080, 32767).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jSeparator2, GroupLayout.Alignment.TRAILING).addComponent(this.jLabel_10ENTER, -1, -1, 32767).addComponent(this.jSeparator3, GroupLayout.Alignment.TRAILING).addComponent(this.jLabel1, -1, -1, 32767).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addComponent(this.jPanel1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jPanel2, -2, -1, -2).addGap(166, 166, 166))).addContainerGap())));
    jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGap(83, 83, 83).addComponent(this.jScrollPane1, -2, -1, -2).addContainerGap(430, 32767)).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel_10ENTER, -2, 49, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jSeparator2, -2, 10, -2).addGap(107, 107, 107).addComponent(this.jSeparator3, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel1, -2, 37, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jPanel1, -1, -1, 32767).addComponent(this.jPanel2, -2, -1, -2)).addContainerGap(30, 32767))));
    this.jMenu_ModificarUsuario.setText("Archivo");
    this.jMenuItem_ModificarUser.setText("Modificar la Contraseña de Acceso al Programa");
    this.jMenuItem_ModificarUser.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem_ModificarUserActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_ModificarUser);
    this.jMenu_ModificarUsuario.add(this.jSeparator1);
    this.jMenuItem_Salir.setText("Salir");
    this.jMenuItem_Salir.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem_SalirActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_Salir);
    this.jMenu2.setText("Tablas");
    this.jMenuItem_10ENTER.setText("Menú Principal | Tablas de Datos");
    this.jMenu2.add(this.jMenuItem_10ENTER);
    this.jMenu2.add(this.jSeparator7);
    this.jMenu2.add(this.jSeparator5);
    this.jMenuItem1.setText("Cuentas de Correos");
    this.jMenuItem1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem1ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem1);
    this.jMenuItem2.setText("Cuentas de Redes Sociales");
    this.jMenuItem2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem2ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem2);
    this.jMenuItem4.setText("Almacenamiento en la Nube");
    this.jMenuItem4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem4ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem4);
    this.jMenuItem5.setText("Portales de Proveedores");
    this.jMenuItem5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem5ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem5);
    this.jMenuItem6.setText("Tiendas OnLine");
    this.jMenuItem6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem6ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem6);
    this.jMenuItem7.setText("Portales de Ocio");
    this.jMenuItem7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem7ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem7);
    this.jMenuItem8.setText("Plataformas de Educación");
    this.jMenuItem8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem8ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem8);
    this.jMenu2.add(this.jSeparator6);
    this.jMenuItem9.setText("Banca OnLine");
    this.jMenuItem9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem9ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem9);
    this.jMenuItem10.setText("Plataformas de Trabajo");
    this.jMenuItem10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem10ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem10);
    this.jMenuItem11.setText("Alojamiento Web");
    this.jMenuItem11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem11ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem11);
    this.jMenuItem12.setText("Administración Web");
    this.jMenuItem12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem12ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem12);
    this.jMenuItem13.setText("Datos 01");
    this.jMenuItem13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem13ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem13);
    this.jMenuItem14.setText("Datos 02");
    this.jMenuItem14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem14ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem14);
    this.jMenuItem15.setText("Datos 03");
    this.jMenuItem15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem15ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem15);
    this.jMenu3.setText("Herramientas");
    this.jMenuItem_passGenerator.setText("Generador de Contraseñas");
    this.jMenuItem_passGenerator.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem_passGeneratorActionPerformed(evt);
          }
        });
    this.jMenu3.add(this.jMenuItem_passGenerator);;
    this.jMenu1.setText("Ayuda");
    this.jMenuItem_Ayuda.setText("Ayuda de ClaveGestión");
    this.jMenuItem_Ayuda.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem_AyudaActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Ayuda);
    this.jMenuItem_Opinion.setText("Enviar opinión...");
    this.jMenuItem_Opinion.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem_OpinionActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Opinion);
    this.jMenu1.add(this.jSeparator4);
    this.jMenuItem_About.setText("Acerca de ClaveGestión");
    this.jMenuItem_About.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface10ENTER.this.jMenuItem_AboutActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_About);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel3, -1, -1, 32767));
    layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel3, -1, -1, 32767));
    pack();
  }
  
  private void jMenuItem_SalirActionPerformed(ActionEvent evt) {
    JMenuBar.salir();
  }
  
  private void jMenuItem_ModificarUserActionPerformed(ActionEvent evt) {
    JMenuBar.modificarUserItem();
    dispose();
  }
  
  private void jButton_CorreosActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Correos");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_RedesSocialesActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Redes Sociales");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem1ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Correos");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem2ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Redes Sociales");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem_AboutActionPerformed(ActionEvent evt) {
    JMenuBar.AboutMe();
  }
  
  private void jMenuItem_AyudaActionPerformed(ActionEvent evt) {
    JMenuBar.LinkPDF();
  }
  
  private void jMenuItem_OpinionActionPerformed(ActionEvent evt) {
    JMenuBar.EnviarOpinion();
  }
  
  private void jButton_CorreosMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Cuentas de Correos:\n     Aquí podrá guardar sus cuentas de correo electrónico.");
  }
  
  private void jButton_CorreosMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_RedesSocialesMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Cuentas de Redes Sociales:\n     Podrá guardar sus cuentas de Redes Sociales, por ejemplo:\n     Facebook y Twitter entre otras.");
  }
  
  private void jButton_NubeMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Almacenamiento en la Nube:\n     Aquí podrá guardar sus espacios virtuales en la Nube. Por ejemplo:\n     DropBox o Mega.");
  }
  
  private void jButton_ProveedoresMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Portales de Proveedores:\n     Podrá guardar sus cuentas con Proveedores, como por ejemplo:\n     Ebay, Amazon,...");
  }
  
  private void jButton_TiendasMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Tiendas OnLine:\n     Aquí podrá guardar sus cuentas de Comercio OnLine, por ejemplo:\n     grandes superficies con venta OnLine.");
  }
  
  private void jButton_OcioMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Portales de Ocio:\n     Podrá guardar sus cuentas de Ocio.");
  }
  
  private void jButton_EducacionMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Plataformas Educativas:\n     Aquí podrá guardar sus cuentas en Academias OnLine\n     o la cuenta del colegio de los niños, por ejemplo.");
  }
  
  private void jButton_BancaMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Banca OnLine:\n     Podrá guardar sus credenciales con sus bancos\n     o su cuenta en PayPal.");
  }
  
  private void jButton_TrabajoMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Plataformas de Trabajo:\n     Aquí podrá guardar sus cuentas de ámbito Laboral.");
  }
  
  private void jButton_HostingMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Alojamiento Web:\n     Podrá guardar sus credenciales si dispone de algún Hosting, Base de Datos Remota\n     o algún servidor FTP.");
  }
  
  private void jButton_SitesMouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Administración de Sitios Web:\n     Aquí podrá guardar sus credenciales si es el Administrador de algún espacio en la web.\n     O si tiene acceso como usuario con privilegios en algún portal web.");
  }
  
  private void jButton_Datos01MouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Cuentas de Datos 01:\n     Espacio sin definir 01.");
  }
  
  private void jButton_Datos02MouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Cuentas de Datos 02:\n     Espacio sin definir 02.");
  }
  
  private void jButton_Datos03MouseMoved(MouseEvent evt) {
    this.jTextArea1.setText("     Cuentas de Datos 03:\n     Espacio sin definir 03.");
  }
  
  private void jButton_RedesSocialesMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_NubeMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_ProveedoresMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_TiendasMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_OcioMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_EducacionMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_BancaMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_TrabajoMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_HostingMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_SitesMouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_Datos01MouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_Datos02MouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_Datos03MouseExited(MouseEvent evt) {
    resetjTextArea1();
  }
  
  private void jButton_NubeActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Almacenamiento en la Nube");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_ProveedoresActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Portales de Proveedores");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_TiendasActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Tiendas OnLine");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_OcioActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Portales de Ocio");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_EducacionActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Plataformas de Educación");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_BancaActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Banca OnLine");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_TrabajoActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Plataformas de Trabajo");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_HostingActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Alojamiento Web");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_SitesActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Administración Web");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_Datos01ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 01");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_Datos02ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 02");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jButton_Datos03ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 03");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem4ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Almacenamiento en la Nube");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem5ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Portales de Proveedores");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem6ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Tiendas OnLine");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem7ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Portales de Ocio");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem8ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Plataformas de Educación");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem9ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Banca OnLine");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem10ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Plataformas de Trabajo");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem11ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Alojamiento Web");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem12ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Administración Web");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem13ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 01");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem14ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 02");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem15ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 03");
    } catch (Exception ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem_passGeneratorActionPerformed(ActionEvent evt) {
    JMenuBar.passGenerator();
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(Interface10ENTER.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            (new Interface10ENTER()).setVisible(true);
          }
        });
  }
}
