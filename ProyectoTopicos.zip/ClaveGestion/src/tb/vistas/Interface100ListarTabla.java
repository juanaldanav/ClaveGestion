package tb.vistas;

import controlador.JMenuBar;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Hashtable;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Action;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.table.DefaultTableModel;
import tb.controlador.ControlTABLAS;
import tb.controlador.ControlVarGlobal;
import tb.controlador.Utilities;
import tb.modelos.TB_Banca;
import tb.modelos.TB_Correo;
import tb.modelos.TB_Datos01;
import tb.modelos.TB_Datos02;
import tb.modelos.TB_Datos03;
import tb.modelos.TB_Educacion;
import tb.modelos.TB_Hosting;
import tb.modelos.TB_Nube;
import tb.modelos.TB_Ocio;
import tb.modelos.TB_Proveedores;
import tb.modelos.TB_RedesSociales;
import tb.modelos.TB_Sites;
import tb.modelos.TB_Tiendas;
import tb.modelos.TB_Trabajo;

public class Interface100ListarTabla extends JFrame {
  private String tabla = ControlVarGlobal.tabla;
  
  private int totalRegistro;
  
  private JLabel[] jlabel = new JLabel[10];
  
  private JTextField[] jtextfield = new JTextField[10];
  
  private String[] columnsEdic;
  
  ControlTABLAS cControlTABLAS = new ControlTABLAS();
  
  Utilities utilities = new Utilities();
  
  String[] enCampo;
  
  private JButton jButton_Copiar;
  
  private JButton jButton_Cortar;
  
  private JButton jButton_Eliminar;
  
  private JButton jButton_Exit;
  
  private JButton jButton_Guardar;
  
  private JButton jButton_MenuPrincipal;
  
  private JButton jButton_Modificar;
  
  private JButton jButton_Pegar;
  
  private JButton jButton_Reset;
  
  private JLabel jLabel0;
  
  private JLabel jLabel1;
  
  private JLabel jLabel2;
  
  private JLabel jLabel3;
  
  private JLabel jLabel4;
  
  private JLabel jLabel5;
  
  private JLabel jLabel6;
  
  private JLabel jLabel7;
  
  private JLabel jLabel8;
  
  private JLabel jLabel9;
  
  private JLabel jLabel_Titulo01;
  
  private JLabel jLabel_Titulo02;
  
  public JMenu jMenu1;
  
  public JMenu jMenu2;
  
  private JMenu jMenu3;
  
  private JMenu jMenu4;
  
  public JMenuBar jMenuBar1;
  
  public JMenuItem jMenuItem1;
  
  private JMenuItem jMenuItem10;
  
  private JMenuItem jMenuItem11;
  
  private JMenuItem jMenuItem12;
  
  private JMenuItem jMenuItem13;
  
  private JMenuItem jMenuItem14;
  
  private JMenuItem jMenuItem15;
  
  private JMenuItem jMenuItem2;
  
  private JMenuItem jMenuItem3;
  
  private JMenuItem jMenuItem4;
  
  private JMenuItem jMenuItem5;
  
  private JMenuItem jMenuItem6;
  
  private JMenuItem jMenuItem7;
  
  private JMenuItem jMenuItem8;
  
  private JMenuItem jMenuItem9;
  
  private JMenuItem jMenuItem_10ENTER;
  
  private JMenuItem jMenuItem_About;
  
  private JMenuItem jMenuItem_Ayuda;
  
  private JMenuItem jMenuItem_Copiar;
  
  private JMenuItem jMenuItem_Cortar;
  
  public JMenuItem jMenuItem_ModificarUser;
  
  private JMenuItem jMenuItem_Opinion;
  
  private JMenuItem jMenuItem_Pegar;
  
  private JMenuItem jMenuItem_Salir;
  
  public JMenuItem jMenuItem_passGenerator;
  
  private JMenu jMenu_ModificarUsuario;
  
  private JPanel jPanel1;
  
  private JPanel jPanel2;
  
  private JPanel jPanel4;
  
  private JScrollPane jScrollPane1;
  
  private JPopupMenu.Separator jSeparator1;
  
  private JPopupMenu.Separator jSeparator2;
  
  private JPopupMenu.Separator jSeparator3;
  
  private JPopupMenu.Separator jSeparator4;
  
  private JPopupMenu.Separator jSeparator5;
  
  private JTable jTable_100ListTabla;
  
  private JTextField jTextField0;
  
  private JTextField jTextField1;
  
  private JTextField jTextField2;
  
  private JTextField jTextField3;
  
  private JTextField jTextField4;
  
  private JTextField jTextField5;
  
  private JTextField jTextField6;
  
  private JTextField jTextField7;
  
  private JTextField jTextField8;
  
  private JTextField jTextField9;
  
  public Action getAccion(Action[] acciones, String nombreAccion) {
    Hashtable<Object, Action> acc = new Hashtable<>();
    for (int i = 0; i < acciones.length; i++) {
      Action accion = acciones[i];
      acc.put(accion.getValue("Name"), accion);
    } 
    return acc.get(nombreAccion);
  }
  
  public void iniAcciones() {
    Action[] acciones = this.jTextField0.getActions();
    this.jButton_Cortar.setAction(getAccion(acciones, "cut-to-clipboard"));
    this.jButton_Copiar.setAction(getAccion(acciones, "copy-to-clipboard"));
    this.jButton_Pegar.setAction(getAccion(acciones, "paste-from-clipboard"));
    this.jButton_Cortar.setText("Cortar");
    this.jButton_Copiar.setText("Copiar");
    this.jButton_Pegar.setText("Pegar");
    this.jMenuItem_Cortar.setAction(getAccion(acciones, "cut-to-clipboard"));
    this.jMenuItem_Copiar.setAction(getAccion(acciones, "copy-to-clipboard"));
    this.jMenuItem_Pegar.setAction(getAccion(acciones, "paste-from-clipboard"));
    this.jMenuItem_Cortar.setText("Cortar     Ctrl+X");
    this.jMenuItem_Copiar.setText("Copiar     Ctrl+C");
    this.jMenuItem_Pegar.setText("Pegar      Ctrl+V");
  }
  
  private void listar100Correo(List<TB_Correo> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Correo.Columns.length; i++)
      defaultTableModel.addColumn(TB_Correo.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Correo.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Correo)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Correo)lista.get(j)).getName());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Correo)lista.get(j)).getServer());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Correo)lista.get(j)).getEmail());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Correo)lista.get(j)).getClave());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Correo)lista.get(j)).getCuentaRecup());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Correo)lista.get(j)).getTelfRecup());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100RedesSociales(List<TB_RedesSociales> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_RedesSociales.Columns.length; i++)
      defaultTableModel.addColumn(TB_RedesSociales.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_RedesSociales.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_RedesSociales)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_RedesSociales)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_RedesSociales)lista.get(j)).getUser());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_RedesSociales)lista.get(j)).getEmail());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_RedesSociales)lista.get(j)).getClave());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_RedesSociales)lista.get(j)).getPhone());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100AlmceNube(List<TB_Nube> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Nube.Columns.length; i++)
      defaultTableModel.addColumn(TB_Nube.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Nube.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Nube)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Nube)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Nube)lista.get(j)).getUrl());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Nube)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Nube)lista.get(j)).getEmail());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Nube)lista.get(j)).getClave());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Nube)lista.get(j)).getPhone());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Proveedores(List<TB_Proveedores> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Proveedores.Columns.length; i++)
      defaultTableModel.addColumn(TB_Proveedores.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Proveedores.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Proveedores)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getUrl());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getEmail());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getClave());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getName());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getAddress());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getPhone());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Proveedores)lista.get(j)).getDate());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Tiendas(List<TB_Tiendas> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Tiendas.Columns.length; i++)
      defaultTableModel.addColumn(TB_Tiendas.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Tiendas.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Tiendas)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getUrl());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getEmail());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getClave());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getName());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getAddress());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getPhone());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Tiendas)lista.get(j)).getDate());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100_Ocio(List<TB_Ocio> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Ocio.Columns.length; i++)
      defaultTableModel.addColumn(TB_Ocio.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Ocio.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Ocio)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Ocio)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Ocio)lista.get(j)).getUrl());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Ocio)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Ocio)lista.get(j)).getEmail());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Ocio)lista.get(j)).getClave());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Ocio)lista.get(j)).getName());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Ocio)lista.get(j)).getPhone());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Educacion(List<TB_Educacion> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Educacion.Columns.length; i++)
      defaultTableModel.addColumn(TB_Educacion.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Educacion.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Educacion)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getUrl());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getEmail());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getClave());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getName());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getCurso());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Educacion)lista.get(j)).getPhone());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Banca(List<TB_Banca> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Banca.Columns.length; i++)
      defaultTableModel.addColumn(TB_Banca.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Banca.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Banca)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Banca)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Banca)lista.get(j)).getUrl());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Banca)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Banca)lista.get(j)).getEmail());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Banca)lista.get(j)).getClave01());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Banca)lista.get(j)).getClave02());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Banca)lista.get(j)).getFirma01());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Banca)lista.get(j)).getFirma02());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Banca)lista.get(j)).getPhone());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Trabajo(List<TB_Trabajo> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Trabajo.Columns.length; i++)
      defaultTableModel.addColumn(TB_Trabajo.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Trabajo.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Trabajo)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getServer());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getUrl());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getEmail());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getClave());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getName());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getAddress());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getPhone());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Trabajo)lista.get(j)).getDate());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Hosting(List<TB_Hosting> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Hosting.Columns.length; i++)
      defaultTableModel.addColumn(TB_Hosting.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Hosting.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Hosting)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getUrl());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getDominio());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getClave());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getEmail());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getContrato());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getName());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getAddress());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getPhone());
      unaRow_Tabla[10] = this.utilities.des1100(((TB_Hosting)lista.get(j)).getDate());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Sites(List<TB_Sites> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Sites.Columns.length; i++)
      defaultTableModel.addColumn(TB_Sites.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Sites.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Sites)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Sites)lista.get(j)).getUrl());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Sites)lista.get(j)).getUrlAdmin());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Sites)lista.get(j)).getUser());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Sites)lista.get(j)).getClave());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Sites)lista.get(j)).getEmail());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Sites)lista.get(j)).getPrivil());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Sites)lista.get(j)).getFtp());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Sites)lista.get(j)).getDb());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Sites)lista.get(j)).getUserDB());
      unaRow_Tabla[10] = this.utilities.des1100(((TB_Sites)lista.get(j)).getClaveDB());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Datos01(List<TB_Datos01> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Datos01.Columns.length; i++)
      defaultTableModel.addColumn(TB_Datos01.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Datos01.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Datos01)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo01());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo02());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo03());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo04());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo05());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo06());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo07());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo08());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo09());
      unaRow_Tabla[10] = this.utilities.des1100(((TB_Datos01)lista.get(j)).getCampo10());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Datos02(List<TB_Datos02> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Datos02.Columns.length; i++)
      defaultTableModel.addColumn(TB_Datos02.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Datos02.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Datos02)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo01());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo02());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo03());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo04());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo05());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo06());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo07());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo08());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo09());
      unaRow_Tabla[10] = this.utilities.des1100(((TB_Datos02)lista.get(j)).getCampo10());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void listar100Datos03(List<TB_Datos03> lista) throws Exception {
    DefaultTableModel defaultTableModel = (DefaultTableModel)this.jTable_100ListTabla.getModel();
    for (int i = 0; i < TB_Datos03.Columns.length; i++)
      defaultTableModel.addColumn(TB_Datos03.Columns[i]); 
    Object[] unaRow_Tabla = new Object[TB_Datos03.Columns.length];
    this.totalRegistro = lista.size();
    textos();
    for (int j = 0; j < lista.size(); j++) {
      unaRow_Tabla[0] = Integer.valueOf(((TB_Datos03)lista.get(j)).getId());
      unaRow_Tabla[1] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo01());
      unaRow_Tabla[2] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo02());
      unaRow_Tabla[3] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo03());
      unaRow_Tabla[4] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo04());
      unaRow_Tabla[5] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo05());
      unaRow_Tabla[6] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo06());
      unaRow_Tabla[7] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo07());
      unaRow_Tabla[8] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo08());
      unaRow_Tabla[9] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo09());
      unaRow_Tabla[10] = this.utilities.des1100(((TB_Datos03)lista.get(j)).getCampo10());
      defaultTableModel.addRow(unaRow_Tabla);
    } 
    this.jTable_100ListTabla.setModel(defaultTableModel);
  }
  
  private void textos() {
    this.jLabel_Titulo01.setText("Total de Registros: " + this.totalRegistro + ".                    Tabla: Cuentas de " + this.tabla + ".");
    if (this.totalRegistro == 0) {
      this.jLabel_Titulo02.setText("Ya puede editar el primer registro.          Máximo 175 caracteres en cada campo.");
    } else {
      this.jLabel_Titulo02.setText("Seleccione un registro para Modificar    o    Puede agregar registros (Guardar).");
    } 
  }
  
  private void edicionJlabel(String[] columns) {
    int i;
    for (i = 0; i < this.jlabel.length; i++)
      this.jlabel[i].setText((String)null); 
    for (i = 0; i < columns.length; i++)
      this.jlabel[i].setText(columns[i]); 
  }
  
  private void edicionJtext(String[] columns) {
    int i;
    for (i = columns.length; i < this.jlabel.length; i++)
      this.jtextfield[i].setVisible(false); 
    for (i = 0; i < columns.length; i++)
      this.jtextfield[i].setText((String)null); 
  }
  
  private void mensajes(String mensaje, String ref, String title) {
    JOptionPane.showMessageDialog(null, mensaje + ref, title, 1);
  }
  
  public Interface100ListarTabla() throws Exception {
    this.enCampo = new String[10];
    initComponents();
    setLocationRelativeTo((Component)null);
    setResizable(false);
    setTitle("ClaveGestión | Tabla: Cuentas de " + this.tabla);
    this.jlabel[0] = this.jLabel0;
    this.jlabel[1] = this.jLabel1;
    this.jlabel[2] = this.jLabel2;
    this.jlabel[3] = this.jLabel3;
    this.jlabel[4] = this.jLabel4;
    this.jlabel[5] = this.jLabel5;
    this.jlabel[6] = this.jLabel6;
    this.jlabel[7] = this.jLabel7;
    this.jlabel[8] = this.jLabel8;
    this.jlabel[9] = this.jLabel9;
    this.jtextfield[0] = this.jTextField0;
    this.jtextfield[1] = this.jTextField1;
    this.jtextfield[2] = this.jTextField2;
    this.jtextfield[3] = this.jTextField3;
    this.jtextfield[4] = this.jTextField4;
    this.jtextfield[5] = this.jTextField5;
    this.jtextfield[6] = this.jTextField6;
    this.jtextfield[7] = this.jTextField7;
    this.jtextfield[8] = this.jTextField8;
    this.jtextfield[9] = this.jTextField9;
    switch (this.tabla) {
      case "Correos":
        listar100Correo(this.cControlTABLAS.controlTBListarCorreo());
        this.columnsEdic = TB_Correo.ColumnsEdic;
        break;
      case "Redes Sociales":
        listar100RedesSociales(this.cControlTABLAS.controlTBListarRedesSociales());
        this.columnsEdic = TB_RedesSociales.ColumnsEdic;
        break;
      case "Almacenamiento en la Nube":
        listar100AlmceNube(this.cControlTABLAS.controlTBListarAlmaceNube());
        this.columnsEdic = TB_Nube.ColumnsEdic;
        break;
      case "Portales de Proveedores":
        listar100Proveedores(this.cControlTABLAS.controlTBListarProveedores());
        this.columnsEdic = TB_Proveedores.ColumnsEdic;
        break;
      case "Tiendas OnLine":
        listar100Tiendas(this.cControlTABLAS.controlTBListarTiendas());
        this.columnsEdic = TB_Tiendas.ColumnsEdic;
        break;
      case "Portales de Ocio":
        listar100_Ocio(this.cControlTABLAS.controlTBListarOcio());
        this.columnsEdic = TB_Ocio.ColumnsEdic;
        break;
      case "Plataformas de Educación":
        listar100Educacion(this.cControlTABLAS.controlTBListarEducacion());
        this.columnsEdic = TB_Educacion.ColumnsEdic;
        break;
      case "Banca OnLine":
        listar100Banca(this.cControlTABLAS.controlTBListarBanca());
        this.columnsEdic = TB_Banca.ColumnsEdic;
        break;
      case "Plataformas de Trabajo":
        listar100Trabajo(this.cControlTABLAS.controlTBListarTrabajo());
        this.columnsEdic = TB_Trabajo.ColumnsEdic;
        break;
      case "Alojamiento Web":
        listar100Hosting(this.cControlTABLAS.controlTBListarHosting());
        this.columnsEdic = TB_Hosting.ColumnsEdic;
        break;
      case "Administración Web":
        listar100Sites(this.cControlTABLAS.controlTBListarSites());
        this.columnsEdic = TB_Sites.ColumnsEdic;
        break;
      case "Datos 01":
        listar100Datos01(this.cControlTABLAS.controlTBListarDatos01());
        this.columnsEdic = TB_Datos01.ColumnsEdic;
        break;
      case "Datos 02":
        listar100Datos02(this.cControlTABLAS.controlTBListarDatos02());
        this.columnsEdic = TB_Datos02.ColumnsEdic;
        break;
      case "Datos 03":
        listar100Datos03(this.cControlTABLAS.controlTBListarDatos03());
        this.columnsEdic = TB_Datos03.ColumnsEdic;
        break;
    } 
    edicionJlabel(this.columnsEdic);
    edicionJtext(this.columnsEdic);
    iniAcciones();
  }
  
  private String[] run04() throws Exception {
    this.enCampo[0] = this.utilities.en1100(this.jTextField0.getText());
    this.enCampo[1] = this.utilities.en1100(this.jTextField1.getText());
    this.enCampo[2] = this.utilities.en1100(this.jTextField2.getText());
    this.enCampo[3] = this.utilities.en1100(this.jTextField3.getText());
    this.enCampo[4] = this.utilities.en1100(this.jTextField4.getText());
    return this.enCampo;
  }
  
  private String[] run05() throws Exception {
    this.enCampo[0] = this.utilities.en1100(this.jTextField0.getText());
    this.enCampo[1] = this.utilities.en1100(this.jTextField1.getText());
    this.enCampo[2] = this.utilities.en1100(this.jTextField2.getText());
    this.enCampo[3] = this.utilities.en1100(this.jTextField3.getText());
    this.enCampo[4] = this.utilities.en1100(this.jTextField4.getText());
    this.enCampo[5] = this.utilities.en1100(this.jTextField5.getText());
    return this.enCampo;
  }
  
  private String[] run06() throws Exception {
    this.enCampo[0] = this.utilities.en1100(this.jTextField0.getText());
    this.enCampo[1] = this.utilities.en1100(this.jTextField1.getText());
    this.enCampo[2] = this.utilities.en1100(this.jTextField2.getText());
    this.enCampo[3] = this.utilities.en1100(this.jTextField3.getText());
    this.enCampo[4] = this.utilities.en1100(this.jTextField4.getText());
    this.enCampo[5] = this.utilities.en1100(this.jTextField5.getText());
    this.enCampo[6] = this.utilities.en1100(this.jTextField6.getText());
    return this.enCampo;
  }
  
  private String[] run07() throws Exception {
    this.enCampo[0] = this.utilities.en1100(this.jTextField0.getText());
    this.enCampo[1] = this.utilities.en1100(this.jTextField1.getText());
    this.enCampo[2] = this.utilities.en1100(this.jTextField2.getText());
    this.enCampo[3] = this.utilities.en1100(this.jTextField3.getText());
    this.enCampo[4] = this.utilities.en1100(this.jTextField4.getText());
    this.enCampo[5] = this.utilities.en1100(this.jTextField5.getText());
    this.enCampo[6] = this.utilities.en1100(this.jTextField6.getText());
    this.enCampo[7] = this.utilities.en1100(this.jTextField7.getText());
    return this.enCampo;
  }
  
  private String[] run08() throws Exception {
    this.enCampo[0] = this.utilities.en1100(this.jTextField0.getText());
    this.enCampo[1] = this.utilities.en1100(this.jTextField1.getText());
    this.enCampo[2] = this.utilities.en1100(this.jTextField2.getText());
    this.enCampo[3] = this.utilities.en1100(this.jTextField3.getText());
    this.enCampo[4] = this.utilities.en1100(this.jTextField4.getText());
    this.enCampo[5] = this.utilities.en1100(this.jTextField5.getText());
    this.enCampo[6] = this.utilities.en1100(this.jTextField6.getText());
    this.enCampo[7] = this.utilities.en1100(this.jTextField7.getText());
    this.enCampo[8] = this.utilities.en1100(this.jTextField8.getText());
    return this.enCampo;
  }
  
  private String[] run09() throws Exception {
    this.enCampo[0] = this.utilities.en1100(this.jTextField0.getText());
    this.enCampo[1] = this.utilities.en1100(this.jTextField1.getText());
    this.enCampo[2] = this.utilities.en1100(this.jTextField2.getText());
    this.enCampo[3] = this.utilities.en1100(this.jTextField3.getText());
    this.enCampo[4] = this.utilities.en1100(this.jTextField4.getText());
    this.enCampo[5] = this.utilities.en1100(this.jTextField5.getText());
    this.enCampo[6] = this.utilities.en1100(this.jTextField6.getText());
    this.enCampo[7] = this.utilities.en1100(this.jTextField7.getText());
    this.enCampo[8] = this.utilities.en1100(this.jTextField8.getText());
    this.enCampo[9] = this.utilities.en1100(this.jTextField9.getText());
    return this.enCampo;
  }
  
  private void guardar() throws Exception {
    TB_Correo tB_Correo;
    TB_RedesSociales tB_RedesSociales;
    TB_Nube tB_Nube;
    TB_Proveedores tB_Proveedores;
    TB_Tiendas tB_Tiendas;
    TB_Ocio tB_Ocio;
    TB_Educacion tB_Educacion;
    TB_Banca tB_Banca;
    TB_Trabajo tB_Trabajo;
    TB_Hosting tB_Hosting;
    TB_Sites tB_Sites;
    TB_Datos01 tB_Datos01;
    TB_Datos02 tB_Datos02;
    TB_Datos03 tB_Datos03;
    switch (this.tabla) {
      case "Correos":
        run05();
        tB_Correo = new TB_Correo(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Correo);
        mensajes("Se ha guardado el Registro: ", this.jTextField2.getText(), "Guardar " + this.tabla);
        break;
      case "Redes Sociales":
        run04();
        tB_RedesSociales = new TB_RedesSociales(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4]);
        this.cControlTABLAS.guardarRegistroTablas(tB_RedesSociales);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Almacenamiento en la Nube":
        run05();
        tB_Nube = new TB_Nube(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Nube);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Portales de Proveedores":
        run08();
        tB_Proveedores = new TB_Proveedores(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Proveedores);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Tiendas OnLine":
        run08();
        tB_Tiendas = new TB_Tiendas(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Tiendas);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Portales de Ocio":
        run06();
        tB_Ocio = new TB_Ocio(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Ocio);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Plataformas de Educación":
        run07();
        tB_Educacion = new TB_Educacion(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Educacion);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Banca OnLine":
        run08();
        tB_Banca = new TB_Banca(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Banca);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Plataformas de Trabajo":
        run08();
        tB_Trabajo = new TB_Trabajo(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Trabajo);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Alojamiento Web":
        run09();
        tB_Hosting = new TB_Hosting(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Hosting);
        mensajes("Se ha guardado el Registro: ", this.jTextField1.getText(), "Guardar " + this.tabla);
        break;
      case "Administración Web":
        run09();
        tB_Sites = new TB_Sites(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Sites);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Datos 01":
        run09();
        tB_Datos01 = new TB_Datos01(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Datos01);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Datos 02":
        run09();
        tB_Datos02 = new TB_Datos02(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Datos02);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
      case "Datos 03":
        run09();
        tB_Datos03 = new TB_Datos03(this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.guardarRegistroTablas(tB_Datos03);
        mensajes("Se ha guardado el Registro: ", this.jTextField0.getText(), "Guardar " + this.tabla);
        break;
    } 
  }
  
  private void modificar(int id) throws Exception {
    TB_Correo tB_Correo;
    TB_RedesSociales tB_RedesSociales;
    TB_Nube tB_Nube;
    TB_Proveedores tB_Proveedores;
    TB_Tiendas tB_Tiendas;
    TB_Ocio tB_Ocio;
    TB_Educacion tB_Educacion;
    TB_Banca tB_Banca;
    TB_Trabajo tB_Trabajo;
    TB_Hosting tB_Hosting;
    TB_Sites tB_Sites;
    TB_Datos01 tB_Datos01;
    TB_Datos02 tB_Datos02;
    TB_Datos03 tB_Datos03;
    switch (this.tabla) {
      case "Correos":
        run05();
        tB_Correo = new TB_Correo(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Correo);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField2.getText(), "Modificar " + this.tabla);
        break;
      case "Redes Sociales":
        run04();
        tB_RedesSociales = new TB_RedesSociales(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4]);
        this.cControlTABLAS.modificarRegistroTablas(tB_RedesSociales);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Almacenamiento en la Nube":
        run05();
        tB_Nube = new TB_Nube(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Nube);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Portales de Proveedores":
        run08();
        tB_Proveedores = new TB_Proveedores(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Proveedores);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Tiendas OnLine":
        run08();
        tB_Tiendas = new TB_Tiendas(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Tiendas);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Portales de Ocio":
        run06();
        tB_Ocio = new TB_Ocio(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Ocio);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Plataformas de Educación":
        run07();
        tB_Educacion = new TB_Educacion(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Educacion);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Banca OnLine":
        run08();
        tB_Banca = new TB_Banca(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Banca);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Plataformas de Trabajo":
        run08();
        tB_Trabajo = new TB_Trabajo(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Trabajo);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Alojamiento Web":
        run09();
        tB_Hosting = new TB_Hosting(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Hosting);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField1.getText(), "Modificar " + this.tabla);
        break;
      case "Administración Web":
        run09();
        tB_Sites = new TB_Sites(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Sites);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Datos 01":
        run09();
        tB_Datos01 = new TB_Datos01(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Datos01);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Datos 02":
        run09();
        tB_Datos02 = new TB_Datos02(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Datos02);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
      case "Datos 03":
        run09();
        tB_Datos03 = new TB_Datos03(id, this.enCampo[0], this.enCampo[1], this.enCampo[2], this.enCampo[3], this.enCampo[4], this.enCampo[5], this.enCampo[6], this.enCampo[7], this.enCampo[8], this.enCampo[9]);
        this.cControlTABLAS.modificarRegistroTablas(tB_Datos03);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Modificar " + this.tabla);
        break;
    } 
  }
  
  private void eliminar(int id) {
    TB_Correo tB_Correo;
    TB_RedesSociales tB_RedesSociales;
    TB_Nube tB_Nube;
    TB_Proveedores tB_Proveedores;
    TB_Tiendas tB_Tiendas;
    TB_Ocio tB_Ocio;
    TB_Educacion tB_Educacion;
    TB_Banca tB_Banca;
    TB_Trabajo tB_Trabajo;
    TB_Hosting tB_Hosting;
    TB_Sites tB_Sites;
    TB_Datos01 tB_Datos01;
    TB_Datos02 tB_Datos02;
    TB_Datos03 tB_Datos03;
    switch (this.tabla) {
      case "Correos":
        tB_Correo = new TB_Correo(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Correo);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField2.getText(), "Eliminar " + this.tabla);
        break;
      case "Redes Sociales":
        tB_RedesSociales = new TB_RedesSociales(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_RedesSociales);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Almacenamiento en la Nube":
        tB_Nube = new TB_Nube(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Nube);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Portales de Proveedores":
        tB_Proveedores = new TB_Proveedores(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Proveedores);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Tiendas OnLine":
        tB_Tiendas = new TB_Tiendas(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Tiendas);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Portales de Ocio":
        tB_Ocio = new TB_Ocio(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Ocio);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Plataformas de Educación":
        tB_Educacion = new TB_Educacion(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Educacion);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Banca OnLine":
        tB_Banca = new TB_Banca(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Banca);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Plataformas de Trabajo":
        tB_Trabajo = new TB_Trabajo(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Trabajo);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Alojamiento Web":
        tB_Hosting = new TB_Hosting(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText(), this.jTextField9.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Hosting);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField1.getText(), "Eliminar " + this.tabla);
        break;
      case "Administración Web":
        tB_Sites = new TB_Sites(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText(), this.jTextField9.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Sites);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Datos 01":
        tB_Datos01 = new TB_Datos01(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText(), this.jTextField9.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Datos01);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Datos 02":
        tB_Datos02 = new TB_Datos02(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText(), this.jTextField9.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Datos02);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
      case "Datos 03":
        tB_Datos03 = new TB_Datos03(id, this.jTextField0.getText(), this.jTextField1.getText(), this.jTextField2.getText(), this.jTextField3.getText(), this.jTextField4.getText(), this.jTextField5.getText(), this.jTextField6.getText(), this.jTextField7.getText(), this.jTextField8.getText(), this.jTextField9.getText());
        this.cControlTABLAS.eliminarRegistroTablas(tB_Datos03);
        mensajes("Operación en el Registro: ID", " " + id + " | " + this.jTextField0.getText(), "Eliminar " + this.tabla);
        break;
    } 
  }
  
  private void linkTabla(String tabla) throws Exception {
    ControlVarGlobal.tabla = tabla;
    JMenuBar.Select100ListarTabla();
    dispose();
  }
  
  private void initComponents() {
    this.jMenuItem3 = new JMenuItem();
    this.jPanel4 = new JPanel();
    this.jScrollPane1 = new JScrollPane();
    this.jTable_100ListTabla = new JTable();
    this.jLabel_Titulo01 = new JLabel();
    this.jLabel_Titulo02 = new JLabel();
    this.jButton_Guardar = new JButton();
    this.jButton_Modificar = new JButton();
    this.jButton_Eliminar = new JButton();
    this.jButton_Reset = new JButton();
    this.jButton_Exit = new JButton();
    this.jButton_MenuPrincipal = new JButton();
    this.jPanel1 = new JPanel();
    this.jLabel0 = new JLabel();
    this.jTextField0 = new JTextField();
    this.jLabel1 = new JLabel();
    this.jTextField1 = new JTextField();
    this.jLabel2 = new JLabel();
    this.jTextField2 = new JTextField();
    this.jLabel3 = new JLabel();
    this.jTextField3 = new JTextField();
    this.jLabel4 = new JLabel();
    this.jTextField4 = new JTextField();
    this.jPanel2 = new JPanel();
    this.jLabel5 = new JLabel();
    this.jTextField5 = new JTextField();
    this.jLabel6 = new JLabel();
    this.jTextField6 = new JTextField();
    this.jLabel7 = new JLabel();
    this.jTextField7 = new JTextField();
    this.jLabel8 = new JLabel();
    this.jTextField8 = new JTextField();
    this.jLabel9 = new JLabel();
    this.jTextField9 = new JTextField();
    this.jButton_Cortar = new JButton();
    this.jButton_Copiar = new JButton();
    this.jButton_Pegar = new JButton();
    this.jMenuBar1 = new JMenuBar();
    this.jMenu_ModificarUsuario = new JMenu();
    this.jMenuItem_ModificarUser = new JMenuItem();
    this.jSeparator1 = new JPopupMenu.Separator();
    this.jMenuItem_Salir = new JMenuItem();
    this.jMenu4 = new JMenu();
    this.jMenuItem_Cortar = new JMenuItem();
    this.jMenuItem_Copiar = new JMenuItem();
    this.jMenuItem_Pegar = new JMenuItem();
    this.jMenu2 = new JMenu();
    this.jMenuItem_10ENTER = new JMenuItem();
    this.jSeparator5 = new JPopupMenu.Separator();
    this.jSeparator3 = new JPopupMenu.Separator();
    this.jMenuItem1 = new JMenuItem();
    this.jMenuItem2 = new JMenuItem();
    this.jMenuItem4 = new JMenuItem();
    this.jMenuItem5 = new JMenuItem();
    this.jMenuItem6 = new JMenuItem();
    this.jMenuItem7 = new JMenuItem();
    this.jMenuItem8 = new JMenuItem();
    this.jSeparator4 = new JPopupMenu.Separator();
    this.jMenuItem9 = new JMenuItem();
    this.jMenuItem10 = new JMenuItem();
    this.jMenuItem11 = new JMenuItem();
    this.jMenuItem12 = new JMenuItem();
    this.jMenuItem13 = new JMenuItem();
    this.jMenuItem14 = new JMenuItem();
    this.jMenuItem15 = new JMenuItem();
    this.jMenu3 = new JMenu();
    this.jMenuItem_passGenerator = new JMenuItem();
    this.jMenu1 = new JMenu();
    this.jMenuItem_Ayuda = new JMenuItem();
    this.jMenuItem_Opinion = new JMenuItem();
    this.jSeparator2 = new JPopupMenu.Separator();
    this.jMenuItem_About = new JMenuItem();
    this.jMenuItem3.setText("jMenuItem3");
    setDefaultCloseOperation(3);
    setMinimumSize(new Dimension(800, 760));
    setPreferredSize(new Dimension(800, 760));
    this.jPanel4.setBackground(new Color(229, 228, 243));
    this.jScrollPane1.setMaximumSize(new Dimension(452, 402));
    this.jScrollPane1.setMinimumSize(new Dimension(452, 402));
    this.jScrollPane1.setName("");
    this.jTable_100ListTabla.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
    this.jTable_100ListTabla.addMouseListener(new MouseAdapter() {
          public void mouseClicked(MouseEvent evt) {
            Interface100ListarTabla.this.jTable_100ListTablaMouseClicked(evt);
          }
        });
    this.jScrollPane1.setViewportView(this.jTable_100ListTabla);
    this.jLabel_Titulo01.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel_Titulo01.setText("jLabel_Titulo01");
    this.jLabel_Titulo02.setFont(new Font("Ubuntu", 1, 18));
    this.jLabel_Titulo02.setText("jLabel_Titulo02");
    this.jButton_Guardar.setText("Guardar");
    this.jButton_Guardar.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jButton_GuardarActionPerformed(evt);
          }
        });
    this.jButton_Modificar.setText("Modificar");
    this.jButton_Modificar.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jButton_ModificarActionPerformed(evt);
          }
        });
    this.jButton_Eliminar.setText("Eliminar");
    this.jButton_Eliminar.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jButton_EliminarActionPerformed(evt);
          }
        });
    this.jButton_Reset.setText("Reset");
    this.jButton_Reset.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jButton_ResetActionPerformed(evt);
          }
        });
    this.jButton_Exit.setText("Salir");
    this.jButton_Exit.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jButton_ExitActionPerformed(evt);
          }
        });
    this.jButton_MenuPrincipal.setText("Menú Principal");
    this.jButton_MenuPrincipal.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jButton_MenuPrincipalActionPerformed(evt);
          }
        });
    this.jPanel1.setBackground(new Color(229, 228, 243));
    this.jPanel1.setMaximumSize(new Dimension(385, 280));
    this.jPanel1.setMinimumSize(new Dimension(385, 280));
    this.jPanel1.setName("");
    this.jLabel0.setText("jLabel0");
    this.jTextField0.setText("jTextField0");
    this.jTextField0.setMaximumSize(new Dimension(86, 27));
    this.jTextField0.setMinimumSize(new Dimension(86, 27));
    this.jTextField0.setName("");
    this.jLabel1.setText("jLabel1");
    this.jTextField1.setText("jTextField1");
    this.jTextField1.setMaximumSize(new Dimension(86, 27));
    this.jTextField1.setMinimumSize(new Dimension(86, 27));
    this.jTextField1.setName("");
    this.jLabel2.setText("jLabel2");
    this.jTextField2.setText("jTextField2");
    this.jTextField2.setMaximumSize(new Dimension(86, 27));
    this.jTextField2.setMinimumSize(new Dimension(86, 27));
    this.jTextField2.setName("");
    this.jLabel3.setText("jLabel3");
    this.jTextField3.setText("jTextField3");
    this.jTextField3.setMaximumSize(new Dimension(86, 27));
    this.jTextField3.setMinimumSize(new Dimension(86, 27));
    this.jTextField3.setName("");
    this.jLabel4.setText("jLabel4");
    this.jTextField4.setText("jTextField4");
    this.jTextField4.setMaximumSize(new Dimension(86, 27));
    this.jTextField4.setMinimumSize(new Dimension(86, 27));
    this.jTextField4.setName("");
    GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
    this.jPanel1.setLayout(jPanel1Layout);
    jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel0, -1, -1, 32767).addComponent(this.jLabel1, -1, -1, 32767).addComponent(this.jTextField1, -1, -1, 32767).addComponent(this.jTextField0, -1, 385, 32767).addComponent(this.jLabel2, -1, -1, 32767).addComponent(this.jTextField2, -1, -1, 32767).addComponent(this.jLabel3, -1, -1, 32767).addComponent(this.jTextField3, -1, -1, 32767).addComponent(this.jLabel4, -1, -1, 32767).addComponent(this.jTextField4, -1, -1, 32767));
    jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel0).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField0, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField2, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField3, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField4, -2, -1, -2).addGap(0, 6, 32767)));
    this.jPanel2.setBackground(new Color(229, 228, 243));
    this.jPanel2.setMaximumSize(new Dimension(385, 280));
    this.jPanel2.setMinimumSize(new Dimension(385, 280));
    this.jPanel2.setName("");
    this.jLabel5.setText("jLabel5");
    this.jTextField5.setText("jTextField5");
    this.jTextField5.setMaximumSize(new Dimension(86, 27));
    this.jTextField5.setMinimumSize(new Dimension(86, 27));
    this.jTextField5.setName("");
    this.jLabel6.setText("jLabel6");
    this.jTextField6.setText("jTextField6");
    this.jTextField6.setMaximumSize(new Dimension(86, 27));
    this.jTextField6.setMinimumSize(new Dimension(86, 27));
    this.jTextField6.setName("");
    this.jLabel7.setText("jLabel7");
    this.jTextField7.setText("jTextField7");
    this.jTextField7.setMaximumSize(new Dimension(86, 27));
    this.jTextField7.setMinimumSize(new Dimension(86, 27));
    this.jTextField7.setName("");
    this.jLabel8.setText("jLabel8");
    this.jTextField8.setText("jTextField8");
    this.jTextField8.setMaximumSize(new Dimension(86, 27));
    this.jTextField8.setMinimumSize(new Dimension(86, 27));
    this.jTextField8.setName("");
    this.jLabel9.setText("jLabel9");
    this.jTextField9.setText("jTextField9");
    this.jTextField9.setMaximumSize(new Dimension(86, 27));
    this.jTextField9.setMinimumSize(new Dimension(86, 27));
    this.jTextField9.setName("");
    GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
    this.jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel5, -1, -1, 32767).addComponent(this.jTextField5, -1, 385, 32767).addComponent(this.jLabel6, -1, -1, 32767).addComponent(this.jTextField6, -1, -1, 32767).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.jTextField7, -1, -1, 32767).addComponent(this.jLabel8, -1, -1, 32767).addComponent(this.jTextField8, -1, -1, 32767).addComponent(this.jLabel9, -1, -1, 32767).addComponent(this.jTextField9, -1, -1, 32767));
    jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel5).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField5, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel6).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField6, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel7).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField7, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel8).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField8, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel9).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField9, -2, -1, -2).addGap(0, 6, 32767)));
    this.jButton_Cortar.setText("Cortar");
    this.jButton_Copiar.setText("Copiar");
    this.jButton_Pegar.setText("Pegar");
    GroupLayout jPanel4Layout = new GroupLayout(this.jPanel4);
    this.jPanel4.setLayout(jPanel4Layout);
    jPanel4Layout.setHorizontalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addContainerGap().addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel_Titulo01, GroupLayout.Alignment.TRAILING, -1, 788, 32767).addComponent(this.jScrollPane1, -1, -1, 32767).addComponent(this.jLabel_Titulo02, -1, -1, 32767).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jButton_Eliminar).addGap(18, 18, 18).addComponent(this.jButton_Modificar).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jButton_Guardar, -2, 178, -2).addGap(43, 43, 43).addComponent(this.jButton_MenuPrincipal).addGap(18, 18, 18).addComponent(this.jButton_Reset).addGap(18, 18, 18).addComponent(this.jButton_Exit)).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jPanel1, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, 32767).addComponent(this.jPanel2, -1, -1, 32767)).addGroup(GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jButton_Cortar).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jButton_Copiar).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jButton_Pegar))).addContainerGap()));
    jPanel4Layout.setVerticalGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel4Layout.createSequentialGroup().addComponent(this.jLabel_Titulo01, -2, 31, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -2, 289, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton_Cortar).addComponent(this.jButton_Copiar).addComponent(this.jButton_Pegar)).addGap(18, 18, 18).addComponent(this.jLabel_Titulo02, -2, 19, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -2, -1, -2).addComponent(this.jPanel2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel4Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton_Guardar).addComponent(this.jButton_Modificar).addComponent(this.jButton_Eliminar).addComponent(this.jButton_Reset).addComponent(this.jButton_Exit).addComponent(this.jButton_MenuPrincipal)).addGap(0, 8, 32767)));
    this.jMenu_ModificarUsuario.setText("Archivo");
    this.jMenuItem_ModificarUser.setText("Modificar la Contraseña de Acceso al Programa");
    this.jMenuItem_ModificarUser.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem_ModificarUserActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_ModificarUser);
    this.jMenu_ModificarUsuario.add(this.jSeparator1);
    this.jMenuItem_Salir.setText("Salir");
    this.jMenuItem_Salir.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem_SalirActionPerformed(evt);
          }
        });
    this.jMenu_ModificarUsuario.add(this.jMenuItem_Salir);
    this.jMenu4.setText("Editar");
    this.jMenuItem_Cortar.setText("Cortar     Ctrl+X");
    this.jMenu4.add(this.jMenuItem_Cortar);
    this.jMenuItem_Copiar.setText("Copiar     Ctrl+C");
    this.jMenu4.add(this.jMenuItem_Copiar);
    this.jMenuItem_Pegar.setText("Pegar     Ctrl+V");
    this.jMenu4.add(this.jMenuItem_Pegar);
    this.jMenu2.setText("Tablas");
    this.jMenuItem_10ENTER.setText("Menú Principal | Tablas de Datos");
    this.jMenuItem_10ENTER.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem_10ENTERActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem_10ENTER);
    this.jMenu2.add(this.jSeparator5);
    this.jMenu2.add(this.jSeparator3);
    this.jMenuItem1.setText("Cuentas de Correos");
    this.jMenuItem1.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem1ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem1);
    this.jMenuItem2.setText("Cuentas de Redes Sociales");
    this.jMenuItem2.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem2ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem2);
    this.jMenuItem4.setText("Almacenamiento en la Nube");
    this.jMenuItem4.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem4ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem4);
    this.jMenuItem5.setText("Portales de Proveedores");
    this.jMenuItem5.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem5ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem5);
    this.jMenuItem6.setText("Tiendas OnLine");
    this.jMenuItem6.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem6ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem6);
    this.jMenuItem7.setText("Portales de Ocio");
    this.jMenuItem7.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem7ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem7);
    this.jMenuItem8.setText("Plataformas de Educación");
    this.jMenuItem8.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem8ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem8);
    this.jMenu2.add(this.jSeparator4);
    this.jMenuItem9.setText("Banca OnLine");
    this.jMenuItem9.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem9ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem9);
    this.jMenuItem10.setText("Plataformas de Trabajo");
    this.jMenuItem10.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem10ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem10);
    this.jMenuItem11.setText("Alojamiento Web");
    this.jMenuItem11.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem11ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem11);
    this.jMenuItem12.setText("Administración Web");
    this.jMenuItem12.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem12ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem12);
    this.jMenuItem13.setText("Datos 01");
    this.jMenuItem13.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem13ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem13);
    this.jMenuItem14.setText("Datos 02");
    this.jMenuItem14.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem14ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem14);
    this.jMenuItem15.setText("Datos 03");
    this.jMenuItem15.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem15ActionPerformed(evt);
          }
        });
    this.jMenu2.add(this.jMenuItem15);
    this.jMenu3.setText("Herramientas");
    this.jMenuItem_passGenerator.setText("Generador de Contrase�as");
    this.jMenuItem_passGenerator.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem_passGeneratorActionPerformed(evt);
          }
        });
    this.jMenu3.add(this.jMenuItem_passGenerator);
    this.jMenu1.setText("Ayuda");
    this.jMenuItem_Ayuda.setText("Ayuda de ClaveGestión");
    this.jMenuItem_Ayuda.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem_AyudaActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Ayuda);
    this.jMenuItem_Opinion.setText("Enviar opinión...");
    this.jMenuItem_Opinion.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem_OpinionActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_Opinion);
    this.jMenu1.add(this.jSeparator2);
    this.jMenuItem_About.setText("Acerca de ClaveGestión");
    this.jMenuItem_About.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent evt) {
            Interface100ListarTabla.this.jMenuItem_AboutActionPerformed(evt);
          }
        });
    this.jMenu1.add(this.jMenuItem_About);
    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel4, -1, -1, 32767));
    layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel4, -1, -1, 32767));
    pack();
  }
  
  private void jMenuItem_SalirActionPerformed(ActionEvent evt) {
    JMenuBar.salir();
  }
  
  private void jMenuItem_ModificarUserActionPerformed(ActionEvent evt) {
    JMenuBar.modificarUserItem();
    dispose();
  }
  
  private void jMenuItem_10ENTERActionPerformed(ActionEvent evt) {
    JMenuBar.Select10Enter();
    dispose();
  }
  
  private void jTable_100ListTablaMouseClicked(MouseEvent evt) {
    this.jLabel_Titulo02.setText("Registro seleccionado ID: " + this.jTable_100ListTabla.getValueAt(this.jTable_100ListTabla.getSelectedRow(), 0) + ".   Puede Modificarlo, Eliminarlo o Guardarlo como nuevo.");
    for (int i = 0; i < this.columnsEdic.length; i++)
      this.jtextfield[i].setText((String)this.jTable_100ListTabla.getValueAt(this.jTable_100ListTabla.getSelectedRow(), i + 1)); 
  }
  
  private void jButton_ResetActionPerformed(ActionEvent evt) {
    textos();
    edicionJtext(this.columnsEdic);
    try {
      JMenuBar.Select100ListarTabla();
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    dispose();
  }
  
  private void jButton_ExitActionPerformed(ActionEvent evt) {
    JMenuBar.salir();
  }
  
  private void jButton_MenuPrincipalActionPerformed(ActionEvent evt) {
    JMenuBar.Select10Enter();
    dispose();
  }
  
  private void jButton_GuardarActionPerformed(ActionEvent evt) {
    try {
      guardar();
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    try {
      JMenuBar.Select100ListarTabla();
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    dispose();
  }
  
  private void jButton_ModificarActionPerformed(ActionEvent evt) {
    try {
      modificar(((Integer)this.jTable_100ListTabla.getValueAt(this.jTable_100ListTabla.getSelectedRow(), 0)).intValue());
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    try {
      JMenuBar.Select100ListarTabla();
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    dispose();
  }
  
  private void jButton_EliminarActionPerformed(ActionEvent evt) {
    eliminar(((Integer)this.jTable_100ListTabla.getValueAt(this.jTable_100ListTabla.getSelectedRow(), 0)).intValue());
    try {
      JMenuBar.Select100ListarTabla();
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    dispose();
  }
  
  private void jMenuItem1ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Correos");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem2ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Redes Sociales");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem_AboutActionPerformed(ActionEvent evt) {
    JMenuBar.AboutMe();
  }
  
  private void jMenuItem_AyudaActionPerformed(ActionEvent evt) {
    JMenuBar.LinkPDF();
  }
  
  private void jMenuItem_OpinionActionPerformed(ActionEvent evt) {
    JMenuBar.EnviarOpinion();
  }
  
  private void jMenuItem4ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Almacenamiento en la Nube");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem5ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Portales de Proveedores");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem6ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Tiendas OnLine");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem7ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Portales de Ocio");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem8ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Plataformas de Educación");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem9ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Banca OnLine");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem10ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Plataformas de Trabajo");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem11ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Alojamiento Web");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem12ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Administración Web");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem13ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 01");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem14ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 02");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem15ActionPerformed(ActionEvent evt) {
    try {
      linkTabla("Datos 03");
    } catch (Exception ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
  }
  
  private void jMenuItem_passGeneratorActionPerformed(ActionEvent evt) {
    JMenuBar.passGenerator();
  }
  
  public static void main(String[] args) {
    try {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        } 
      } 
    } catch (ClassNotFoundException ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (InstantiationException ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (IllegalAccessException ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } catch (UnsupportedLookAndFeelException ex) {
      Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
    } 
    EventQueue.invokeLater(new Runnable() {
          public void run() {
            try {
              (new Interface100ListarTabla()).setVisible(true);
            } catch (Exception ex) {
              Logger.getLogger(Interface100ListarTabla.class.getName()).log(Level.SEVERE, (String)null, ex);
            } 
          }
        });
  }
}
