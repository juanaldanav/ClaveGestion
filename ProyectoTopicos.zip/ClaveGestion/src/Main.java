import vistas.Interface01APP;

public class Main {
  public static void main(String[] args) {
    Interface01APP interface01APP = new Interface01APP();
    interface01APP.setVisible(true);
  }
}


