package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import tb.controlador.Utilities;

public class ConexionLogin {
  private Connection conexion;
  
  private final String classFor;
  
  private final String url;
  
  private String sql;
  
  Utilities utilities = new Utilities();
  
  public ConexionLogin() {
    this.conexion = null;
    this.classFor = "org.apache.derby.jdbc.EmbeddedDriver";
    this.url = "jdbc:derby:ClaveGestion_DB";
  }
  
  public Connection conexionLoginBD() {
    try {
      Class.forName(this.classFor);
      this.conexion = DriverManager.getConnection(this.url);
    } catch (ClassNotFoundException|SQLException e) {
      JOptionPane.showMessageDialog(null, e.getMessage() + ": Error de Conexion con la Base de Datos #100.", "Conexionn con la Base de Datos", 0);
    } 
    return this.conexion;
  }
  
  public Connection conexionLoginFirst() throws Exception {
    try {
      Class.forName(this.classFor);
      this.conexion = DriverManager.getConnection(this.url);
      JOptionPane.showMessageDialog(null, "Bienvenido a ClaveGestion.\nSu Gestor de Contrase�as.", "Iniciando el Programa...", 1);
    } catch (ClassNotFoundException|SQLException e) {
      JOptionPane.showMessageDialog(null, "Configurando el primer uso del programa.\nCreando las Bases de Datos.\nEsto puede tardar un minuto.\nPor favor espere...", "Estableciendo primer uso del programa", 1);
      primerUso();
    } 
    return this.conexion;
  }
  
  private void primerUso() throws Exception {
    PreparedStatement ps = null;
    this.sql = "CREATE TABLE usuario552 (  id_user INT NOT NULL,  name_user VARCHAR(44) NOT NULL,  password_user VARCHAR(44) NOT NULL,  PRIMARY KEY (id_user))";
    try {
      Class.forName(this.classFor);
      this.conexion = DriverManager.getConnection(this.url + "; create = true;");
      JOptionPane.showMessageDialog(null, "La Base de Datos ha sido creada correctamente.\nUn momento, por favor...", "Estableciendo primer uso del programa", 1);
      this.utilities.genLi0000();
      try {
        ps = this.conexion.prepareStatement(this.sql);
        if (ps.executeUpdate() >= 0) {
          JOptionPane.showMessageDialog(null, "Felicidades ClaveGestion se ha iniciado correctamente.", "Estableciendo primer uso del programa", 1);
        } else {
          JOptionPane.showMessageDialog(null, "El programa se ha iniciado con Errores #011.", "Estableciendo primer uso del programa", 0);
        } 
      } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex.getLocalizedMessage() + ": Error de Inicialización #010.", "Estableciendo primer uso del programa", 0);
      } 
    } catch (SQLException|ClassNotFoundException ex) {
      JOptionPane.showMessageDialog(null, ex.getMessage() + ": Error de la Base de Datos #020", "Estableciendo primer uso del programa", 0);
    } 
  }
}


