package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import modelos.Usuario;
import tb.controlador.Utilities;
import vistas.Interface02Registro;
import vistas.Interface03Login;

public class UsuarioLogin {
  ConexionLogin conexion;
  
  Connection conDB;
  
  String sql;
  
  ResultSet rs;
  
  LinkedList<Usuario> listaUsuario;
  
  Usuario unUsuario;
  
  Utilities utilities = new Utilities();
  
  public UsuarioLogin() {
    this.conexion = new ConexionLogin();
    this.conDB = null;
    this.rs = null;
    this.listaUsuario = new LinkedList<>();
  }
  
  public LinkedList<Usuario> listarUsuario() {
    this.listaUsuario.clear();
    PreparedStatement ps = null;
    this.sql = "SELECT * FROM usuario552";
    try {
      this.conDB = this.conexion.conexionLoginBD();
      ps = this.conDB.prepareStatement(this.sql);
      this.rs = ps.executeQuery();
      while (this.rs.next()) {
        this.unUsuario = new Usuario(this.rs.getInt(1), this.utilities.des1100(this.rs.getString(2)), this.rs.getString(3));
        this.listaUsuario.add(this.unUsuario);
      } 
      ps.close();
      this.conDB.close();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecucion.", "Listar Usuarios", 0);
      JMenuBar.operacionNoPermitida();
    } 
    return this.listaUsuario;
  }
  
  public void registrarUsuario(Usuario usuario) {
    PreparedStatement ps = null;
    this.sql = "INSERT INTO usuario552 values (1,?,?)";
    try {
      this.conDB = this.conexion.conexionLoginBD();
      ps = this.conDB.prepareStatement(this.sql);
      ps.setString(1, usuario.getName());
      ps.setString(2, usuario.getPassword());
      if (ps.executeUpdate() >= 0) {
        JOptionPane.showMessageDialog(null, "El Usuario ha sido creado correctamente.", "Crear Usuario", 1);
      } else {
        JOptionPane.showMessageDialog(null, "Error de creacción de Usuario.", "Crear Usuario", 0);
      } 
      ps.close();
      this.conDB.close();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecución.", "Crear Usuario", 0);
    } 
  }
  
  public void modificarUsuario(Usuario usuario) {
    PreparedStatement ps = null;
    this.sql = "UPDATE usuario552 SET name_user = ?, password_user = ? WHERE id_user = ?";
    try {
      this.conDB = this.conexion.conexionLoginBD();
      ps = this.conDB.prepareStatement(this.sql);
      ps.setString(1, usuario.getName());
      ps.setString(2, usuario.getPassword());
      ps.setString(3, "1");
      if (ps.executeUpdate() >= 0) {
        JOptionPane.showMessageDialog(null, "El Usuario ha sido modificado correctamente.", "Modificar Usuario", 1);
      } else {
        JOptionPane.showMessageDialog(null, "Error de modificación de Usuario.", "Modificar Usuario", 0);
      } 
      ps.close();
      this.conDB.close();
    } catch (Exception e) {
      JOptionPane.showMessageDialog(null, "Error de Ejecución.", "Modificar Usuario", 0);
    } 
  }
  
  public boolean logearUsuario(Usuario usuario) {
    String controlName = null;
    String controlPassword = null;
    this.listaUsuario = listarUsuario();
    if (this.listaUsuario.size() == 1) {
      controlName = ((Usuario)this.listaUsuario.get(0)).getName();
      controlPassword = ((Usuario)this.listaUsuario.get(0)).getPassword();
    } 
    if (controlName.equals(usuario.getName()) && controlPassword.equals(usuario.getPassword()))
      return true; 
    return false;
  }
  
  public void controlUsuario() throws Exception {
    Interface02Registro interface02Login;
    Interface03Login interface03Login;
    this.utilities.genLlav0100();
    this.listaUsuario = listarUsuario();
    int cant = this.listaUsuario.size();
    switch (cant) {
      case 0:
        interface02Login = new Interface02Registro();
        interface02Login.setVisible(true);
        return;
      case 1:
        interface03Login = new Interface03Login();
        interface03Login.setVisible(true);
        return;
    } 
    JMenuBar.operacionNoPermitida();
    System.exit(0);
  }
}


