package controlador;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Organizador {
  private JTextField var01;
  
  private JTextField var02;
  
  private JTextField var03;
  
  public void reset3(JTextField var01, JTextField var02, JTextField var03) {
    this.var01 = var01;
    this.var02 = var02;
    this.var03 = var03;
    this.var01.setText(null);
    this.var02.setText(null);
    this.var03.setText(null);
  }
  
  public boolean validarRegistro(JTextField var01, JTextField var02, JTextField var03) {
    boolean control = true;
    this.var01 = var01;
    this.var02 = var02;
    this.var03 = var03;
    String pass01 = this.var02.getText();
    String pass02 = this.var03.getText();
    if (!pass01.equals(pass02)) {
      JOptionPane.showMessageDialog(null, "Atención: No coinciden las Contraseñas.", "Creando Usuario", 0);
      control = false;
    } 
    String name = this.var01.getText();
    if (name.equals("")) {
      JOptionPane.showMessageDialog(null, "Debe indicar un nombre de Usuario.", "Creando Usuario", 0);
      control = false;
    } 
    String pass = this.var02.getText();
    if (pass.equals("")) {
      JOptionPane.showMessageDialog(null, "Debe indicar una Contraseña.", "Creando Usuario", 0);
      control = false;
    } 
    return control;
  }
}


