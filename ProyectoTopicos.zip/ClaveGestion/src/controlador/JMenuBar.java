package controlador;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import javax.swing.JOptionPane;
import tb.vistas.Interface100ListarTabla;
import tb.vistas.Interface10ENTER;
import vistas.Interface04ModificarUser;
import vistas.Interface1000AboutMe;

public class JMenuBar {
  public static void salir() {
    if (JOptionPane.showOptionDialog(null, "¿Realmente desea salir del programa?", "ClaveGestión", 0, 3, null, new Object[] { " Salir ", " Cancelar " }, "NO") == 0)
      System.exit(0); 
  }
  
  public static void operacionNoPermitida() {
    JOptionPane.showMessageDialog(null, "Se ha producido un error.\n\nPara proteger sus datos, ClaveGestión se va a cerrar.\n\nEsta última operación no será Grabada. Disculpe la molestia.", "Operación no permitida:", 0);
    System.exit(0);
  }
  
  public static void modificarUserItem() {
    Interface04ModificarUser interface04ModificarUser = new Interface04ModificarUser();
    interface04ModificarUser.setVisible(true);
  }
  
  public static void Select10Enter() {
    Interface10ENTER interface10ENTER = new Interface10ENTER();
    interface10ENTER.setVisible(true);
  }
  
  public static void Select100ListarTabla() throws Exception {
    Interface100ListarTabla interface100ListarTabla = new Interface100ListarTabla();
    interface100ListarTabla.setVisible(true);
  }
  
  public static void AboutMe() {
    Interface1000AboutMe interface1000AboutMe = new Interface1000AboutMe();
    interface1000AboutMe.setVisible(true);
  }
  
  public static void LinkURL(String link) throws URISyntaxException {
    Desktop enlace = Desktop.getDesktop();
    try {
      enlace.browse(new URI(link));
    } catch (IOException|URISyntaxException e) {
      e.getMessage();
    } 
  }
  
  public static void LinkPDF() {
    try {
      LinkURL("http://clavegestion.juanaldana.es");
    } catch (Exception exception) {}
  }
  
  public static void EnviarOpinion() {
    try {
      LinkURL("https://www.instagram.com/juanaldanav/");
    } catch (Exception exception) {}
  }
  
  public static void passGenerator() {
    try {
      LinkURL("https://www.avast.com/es-mx/random-password-generator#pc");
    } catch (Exception exception) {}
  }
}

